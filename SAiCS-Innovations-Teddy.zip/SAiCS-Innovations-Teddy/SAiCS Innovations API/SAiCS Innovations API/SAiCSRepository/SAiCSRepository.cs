﻿using SAiCS_Innovations_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAiCS_Innovations_API.SAiCSRepository
{
    public class SAiCSRepository
    {
        private readonly SaicsInnovationsDBContext db = new SaicsInnovationsDBContext();

       //Add async
    }
}
