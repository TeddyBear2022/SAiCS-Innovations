//Ambassador class
export class Ambassador{
    CourseID:number
    BankaccountID:number
    UserID: number
    AmbassadorType: number
    IDNumber:number
    IDPhoto:number
    ProofOfAddressPhoto:number
    ProfilePic:number
    ReferralCode:number
}