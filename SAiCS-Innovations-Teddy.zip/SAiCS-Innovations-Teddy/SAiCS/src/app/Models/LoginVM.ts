export class LoginVM{
    EmailorUsername: string
    Password: string
}