import { Ambassador } from "./Ambassador";
import { User } from "./User";

export class AmbassadorVM{
    Ambassador:Ambassador
    User:User 
}