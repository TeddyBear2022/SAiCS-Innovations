export class UserType{
    UserRoleID:number
    AccessLevelID:number
    description:string
    
}