export class Title{
    TitleId:number
    TitleName:string
}