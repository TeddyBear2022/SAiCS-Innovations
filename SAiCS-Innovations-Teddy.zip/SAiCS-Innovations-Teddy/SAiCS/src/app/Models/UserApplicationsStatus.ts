//Application Status class
export class UserApplicationStatus{
    UserApplicationStatus:number
    ApplicationStatusID:number
    UserID:number
}