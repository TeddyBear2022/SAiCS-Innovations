//Admin class
export class Admin{
    UserID:Number
    IDNumber:number
    IDPhoto:string
    ProofOfAddressPhoto:string
}