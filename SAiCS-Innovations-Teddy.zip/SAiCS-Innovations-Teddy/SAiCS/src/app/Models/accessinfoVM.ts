export class accessInfoVM{
    Username:string
    Password:string

    constructor(  password:string, username:string) {
     this.Username = username;
     this.Password = password;
    }
}