import { Client } from "./Client";
import { User } from "./User";

export class ClientVM{
    Client:Client
    User:User 
}