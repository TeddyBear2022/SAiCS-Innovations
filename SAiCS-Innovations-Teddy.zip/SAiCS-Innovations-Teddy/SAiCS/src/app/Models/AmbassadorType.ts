export class AmbassadorType{
    AmbassadorTypeId:number
    AmbassadorTypeName:string
}