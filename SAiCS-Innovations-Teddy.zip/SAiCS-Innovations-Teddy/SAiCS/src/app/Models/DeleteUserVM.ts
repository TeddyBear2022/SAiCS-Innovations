export class DeleteUserVM{
    userId:number
    constructor(userid:number){
        this.userId= userid
    }
}