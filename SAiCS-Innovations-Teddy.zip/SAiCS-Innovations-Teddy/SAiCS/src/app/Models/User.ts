//User Class
export class User{
    UserID:number
    UserRoleID:number
    TitleID:number
    CountryID:number
    AddressID:number
    Username:string
    Password:number
    Name:string
    Surname:string
    EmailAddress:string
    PhoneNumber:number
}