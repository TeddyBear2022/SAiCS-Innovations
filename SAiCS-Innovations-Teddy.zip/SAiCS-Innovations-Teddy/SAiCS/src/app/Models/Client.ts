export class Client{
    ClientID:number
    UserID:number
    //need ambassador id through referral code 
    AmbassadorID:number
}