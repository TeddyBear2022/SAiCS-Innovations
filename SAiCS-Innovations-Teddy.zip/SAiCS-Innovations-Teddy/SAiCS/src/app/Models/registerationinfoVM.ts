export class registerationinfoVM{
    UsertypeID: number
    TitleID:number
    Name:string
    Surname:string
    EmailAddress:string
    PhoneNumber:number
    CountryID:number
    City:number // change to string
    Address:string
    PostalCode:number
    Idnumber:number| null
    referralcode:string;
    ProofOfAdderess:File
    IDPhoto:File;
    AmbassadorRankingID:number
    AliasName:string
    AboutMyself:string;
}