import { Address } from "./Address";
import { Admin } from "./Admin";
import { User } from "./User";

export class AdminVM{
    Admin:Admin
    User:User 
    Address: Address
}