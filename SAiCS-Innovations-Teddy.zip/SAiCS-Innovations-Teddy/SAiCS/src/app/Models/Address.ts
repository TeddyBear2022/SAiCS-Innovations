export class Address{
       Address:string
       PostalCode:number
       City:string
}