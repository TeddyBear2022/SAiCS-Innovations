﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using SAiCSInnovationsAPI_3._0.Models;
using SAiCSInnovationsAPI_3._0.Repository;
using SAiCSInnovationsAPI_3._0.ViewModels;
using SendGrid;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Net.Mail;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace SAiCSInnovationsAPI_3._0.Repository
{
    public class SAiCSInnovationsRep : ISAiCSInnovationsRep
    {
        private readonly SaicsInnovationsDBContext db;
        private readonly UserManager<User> _manager;
        private readonly IUserClaimsPrincipalFactory<User> _claims;
        private readonly IConfiguration _configuration;
        // public int otp = 0;

        public SAiCSInnovationsRep(SaicsInnovationsDBContext _db,
            UserManager<User> manager,
            IUserClaimsPrincipalFactory<User> claims,
            IConfiguration configuration
            )
        {
            db = _db;
            _manager = manager;
            _claims = claims;
            _configuration = configuration;
        }


        //Teddys Repository code
        //Adding a table to the database
        public void Add<T>(T entity) where T : class
        {
            db.Add(entity);
        }

        //Deleteing a table from teh database
        public void Delete<T>(T entity) where T : class
        {
            db.Remove(entity);
        }

        //Saving changes on database
        public bool SaveChanges()
        {
            return db.SaveChanges() > 0;
        }

        //Find ByID
        public T FindById<T>(int id) where T : class
        {
            return db.Set<T>().Find(id);
        }

        //Search DB
        public IEnumerable<T> Search<T>(Expression<Func<T, bool>> predicate) where T : class
        {
            return db.Set<T>().Where(predicate);
        }

        //GetALl from DB
        public List<T> GetAll<T>() where T : class
        {
            return db.Set<T>().ToList();
        }

        public Ambassador FindAmbassador(string email)
        {
            var user = db.Users.Where(user => user.Email == email || user.NormalizedEmail == email).FirstOrDefault();
            var amb = db.Ambassadors.Where(id => id.UserId == user.Id).FirstOrDefault();
            return amb;
        }

        //Register a user
        public void RegisterUser(RegisterVM registration)
        {

            //if admin user
            //if (registration.RegisterInfo.UsertypeID == 3)
            //{
            //    if (RegisterAdmin(registration) == true)
            //    {
            //        return true;
            //    }
            //    else
            //    {
            //        return false;
            //    }
            //}

            //if ambassasdor user
            if (registration.RegisterInfo.UsertypeID == 2)
            {
                RegisterAmbassador(registration);
                //if (RegisterAmbassador(registration) == true)
                //{
                //    return true;
                //}
                //else
                //{
                //    return false;
                //}
            }

            //if client user
            if (registration.RegisterInfo.UsertypeID == 1)
            {
                RegisterClient(registration);

            }

            //else
            //{
            //    //Not registered
            //   /* return false*/;
            //}




        }

        //Finding a FAQ record
        public object FindFAQ(int entityid)
        {
            return db.Faqs.Where(faq => faq.Faqid == entityid).FirstOrDefault();
        }

        //Getting all FAQs
        public object getAllFAQs()
        {
            //var faqs = db.Faqs.Include(category => category.Faqcategory).ThenInclude(type => type.Faqtype).ToList();


            //alt
            var faqs = db.Faqtypes.Include(category => category.Faqcategories).ThenInclude(faq => faq.Faqs).ToList();
            return faqs;
        }

        public void Emails(string email, string username, string password, int usertype)
        {
            if (usertype == 1)

            {
                using (MailMessage emailSend = new MailMessage("u20551313@tuks.co.za", email))
                {
                    emailSend.Subject = "Welcome to SAiCs!!!";
                    emailSend.Body = "Welcome to the SAiCS Innvoation app, we are happy that you chose to do business with us! The following are the details you can use to login :-). Username:" + username + " Password:" + password;
                    emailSend.IsBodyHtml = false;
                    using (SmtpClient Smtp = new SmtpClient())
                    {
                        Smtp.Host = "smtp.gmail.com";
                        Smtp.EnableSsl = true;
                        NetworkCredential credentials = new NetworkCredential("u20551313@tuks.co.za", "FentseT@21");
                        Smtp.UseDefaultCredentials = false;
                        Smtp.Credentials = credentials;
                        Smtp.Port = 587;
                        Smtp.Send(emailSend);
                    }
                }
            }
            if (usertype == 2)
            {
                using (MailMessage emailSend = new MailMessage("u20551313@tuks.co.za", email))
                {
                    emailSend.Subject = "Welcome future SAiCs Ambassador!!!";
                    emailSend.Body = "Congratulations on getting thus far, we are happy that you chose to do business with us! The following are the details you can use to login :-). Username:" + username + " Password:" + password + " Please be aware you will only have access to functionality once admin has verified your account";
                    emailSend.IsBodyHtml = false;

                    using (SmtpClient Smtp = new SmtpClient())
                    {
                        Smtp.Host = "smtp.gmail.com";
                        Smtp.EnableSsl = true;
                        NetworkCredential credentials = new NetworkCredential("u20551313@tuks.co.za", "FentseT@21");
                        Smtp.UseDefaultCredentials = false;
                        Smtp.Credentials = credentials;
                        Smtp.Port = 587;
                        Smtp.Send(emailSend);
                    }
                }
            }
            if (usertype == 3)
            {
                using (MailMessage emailSend = new MailMessage("u20551313@tuks.co.za", email))
                {
                    emailSend.Subject = "Welcome future SAiCs Administrator!!!";
                    emailSend.Body = "Congratulations on getting thus far, we are happy that you chose to do business with us! The following are the details you can use to login :-). Username:" + username + " Password:" + password + " Please be aware you will only have access to functionality once admin has verified your account";
                    emailSend.IsBodyHtml = false;

                    using (SmtpClient Smtp = new SmtpClient())
                    {
                        Smtp.Host = "smtp.gmail.com";
                        Smtp.EnableSsl = true;
                        NetworkCredential credentials = new NetworkCredential("u20551313@tuks.co.za", "FentseT@21");
                        Smtp.UseDefaultCredentials = false;
                        Smtp.Credentials = credentials;
                        Smtp.Port = 587;
                        Smtp.Send(emailSend);
                    }
                }
            }
        }
        //Register a user
        public bool UserExists(string email)
        {
            var user = db.Users.Where(id => id.Email == email || id.NormalizedEmail ==
           email).FirstOrDefault();
            if (user == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        //public bool RegisterUser(RegisterVM registration)
        //{
        //    try
        //    {
        //        //if admin user
        //        if (registration.RegisterInfo.UsertypeID == 3)
        //        {
        //            if (RegisterAdmin(registration) == true)
        //            {
        //                return true;
        //            }
        //            else
        //            {
        //                return false;
        //            }
        //        }

        //        //if ambassasdor user
        //        if (registration.RegisterInfo.UsertypeID == 2)
        //        {
        //            if (RegisterAmbassador(registration) == true)
        //            {
        //                return true;
        //            }
        //            else
        //            {
        //                return false;
        //            }
        //        }

        //        //if client user
        //        if (registration.RegisterInfo.UsertypeID == 1)
        //        {
        //            if (RegisterClient(registration) == true)
        //            {
        //                return true;
        //            }
        //            else
        //            {
        //                return false;
        //            }

        //        }

        //        else
        //        {
        //            //Not registered
        //            return false;
        //        }

        //    }
        //    catch (Exception error)
        //    {
        //        //Error
        //        return false;
        //    }

        //}

        //Register Admin user method
        private bool RegisterAdmin(RegisterVM registration)
        {
            try
            {
                //Creating an admin
                Admin admin = new Admin();
                admin.Idnumber = registration.RegisterInfo.Idnumber;
                admin.Iddocument = null; // amanda solution
                admin.ProofOfAddress = null; // amanda soloution

                //Creating user
                User user = new User();
                user.UserRole = new UserRole { UserRoleId = 3 };
                user.UserRoleId = user.UserRole.UserRoleId;
                user.Title = new Title { TitleId = registration.RegisterInfo.TitleID };
                user.TitleId = user.Title.TitleId;
                user.Name = registration.RegisterInfo.Name;
                user.Surname = registration.RegisterInfo.Surname;
                user.Email = registration.RegisterInfo.EmailAddress;
                user.UserName = registration.RegisterInfo.EmailAddress;
                user.NormalizedEmail = registration.RegisterInfo.EmailAddress.ToUpper();
                user.NormalizedUserName = registration.RegisterInfo.EmailAddress.ToUpper();
                user.PhoneNumber = registration.RegisterInfo.PhoneNumber;
                user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(registration.AccessInfo.Password);
                Password password = new Password { Password1 = BCrypt.Net.BCrypt.HashPassword(registration.AccessInfo.Password), UserId = user.UserId.ToString() };
                Application application = new Application { ApplicationStatusId = 1, UserId = user.Id };

                //Linking Tables
                //Admin->User
                user.Admins.Add(admin);
                admin.User = user;

                //Title->User
                user.Title.Users.Add(user);
                user.Title = user.Title;

                //UserRole->User
                user.UserRole.Users.Add(user);
                user.UserRole = user.UserRole;

                Address address = new Address { Address1 = registration.RegisterInfo.Address, City = registration.RegisterInfo.City, PostalCode = registration.RegisterInfo.PostalCode, CountryId = registration.RegisterInfo.CountryID, UserId = user.Id, Country = new Country { CountryId = registration.RegisterInfo.CountryID } };
                //password->User
                user.Passwords.Add(password);
                password.User = user;

                //userapplicationstatus
                user.Applications.Add(application);

                //Assignings
                //userrole
                db.Entry(user.UserRole).State = EntityState.Unchanged;
                //title
                db.Entry(user.Title).State = EntityState.Unchanged;
                //Country
                db.Entry(address.Country).State = EntityState.Unchanged;

                //Add to database
                db.Applications.Add(application);
                db.Admins.Add(admin);
                db.Addresses.Add(address);


                if (db.SaveChanges() > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception error)
            {
                return false;
            }
        }

        public void UserAmbRegister(RegisterVM registration)
        {

            //Create Ambassador
            Ambassador ambassador = new Ambassador();
            ambassador.AmbassadorType = new AmbassadorType { AmbassadorTypeId = Convert.ToInt32(registration.RegisterInfo.ambassadorType) };
            ambassador.AmbassadorTypeId = ambassador.AmbassadorType.AmbassadorTypeId;
            ambassador.Idnumber = registration.RegisterInfo.Idnumber;
            ambassador.Idphoto = null;
            ambassador.ProofOfAddress = null; //Amanda soloution

            //Create User
            User user = new User();
            user.UserRole = new UserRole { UserRoleId = 2 };
            user.UserRoleId = user.UserRole.UserRoleId;
            user.Title = new Title { TitleId = registration.RegisterInfo.TitleID };
            user.TitleId = user.Title.TitleId;

            user.Name = registration.RegisterInfo.Name;
            user.Surname = registration.RegisterInfo.Surname;
            user.Email = registration.RegisterInfo.EmailAddress;
            user.UserName = registration.RegisterInfo.EmailAddress;
            user.NormalizedEmail = registration.RegisterInfo.EmailAddress.ToUpper();
            user.NormalizedUserName = registration.RegisterInfo.EmailAddress.ToUpper();
            user.PhoneNumber = registration.RegisterInfo.PhoneNumber;
            user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(registration.AccessInfo.Password);
            Password password = new Password { Password1 = BCrypt.Net.BCrypt.HashPassword(registration.AccessInfo.Password), UserId = user.UserId.ToString() };
            // UserApplicationStatus uAPP = new UserApplicationStatus { ApplicationStatusId = 1, UserId = user.UserId.ToString() };

            Application application = new Application { ApplicationStatusId = 1, UserId = user.Id };
            Address address = new Address { Address1 = registration.RegisterInfo.Address, City = registration.RegisterInfo.City, PostalCode = registration.RegisterInfo.PostalCode, CountryId = registration.RegisterInfo.CountryID, ProvinceId = registration.RegisterInfo.ProvinceID, UserId = user.Id, Country = new Country { CountryId = registration.RegisterInfo.CountryID } };
            db.Addresses.Add(address);
            user.Applications.Add(application);

            //User
            user.Ambassadors.Add(ambassador);
            ambassador.User = user;

            //Cart
            Cart cart = new Cart();
            cart.UserId = user.Id;
            Add(cart);

            //Ambassadortype
            ambassador.AmbassadorType.Ambassadors.Add(ambassador);
            ambassador.AmbassadorType = ambassador.AmbassadorType;

            //userrole
            user.UserRole.Users.Add(user);
            user.UserRole = user.UserRole;

            //title
            user.Title.Users.Add(user);
            user.Title = user.Title;

            //password
            user.Passwords.Add(password);
            password.User = user;


            //Assignings
            //userrole
            db.Entry(user.UserRole).State = EntityState.Unchanged;
            //title
            db.Entry(user.Title).State = EntityState.Unchanged;
            //Country
            db.Entry(address.Country).State = EntityState.Unchanged;
            //Ambassador Type
            db.Entry(ambassador.AmbassadorType).State = EntityState.Unchanged;

            //add to database
            //db.UserApplicationStatuses.Add(uAPP);
            db.Applications.Add(application);
            db.Ambassadors.Add(ambassador);
            db.SaveChanges();

            //giving ambassador their refferal code
            ReferralCode code = new ReferralCode();
            code.AmbassadorId = ambassador.AmbassadorId;
            code.IsActive = "true";
            var newRefferalCode = GenerateRefferralCode(registration.RegisterInfo.Name, registration.RegisterInfo.Surname, registration.RegisterInfo.referralcode).ToString();
            var existingRefferalCode = db.ReferralCodes.Where(code => code.ReferralCode1 == newRefferalCode).FirstOrDefault();

            //if generated refferral code doesnt already exist
            if (existingRefferalCode == null)
            {
                code.ReferralCode1 = newRefferalCode;
                Add(code);
                db.SaveChanges();
            }

            //if generated refferral code already exists
            if (existingRefferalCode != null)
            {
                code.ReferralCode1 = GenerateRefferralCode(registration.RegisterInfo.Name, registration.RegisterInfo.Surname, registration.RegisterInfo.referralcode).ToString();
                Add(code);
                db.SaveChanges();
            }

            //Create a linkage between the users through refferral code
            //LinkUsers(registration.RegisterInfo.referralcode, registration.RegisterInfo.EmailAddress, "Ambassador");




        }

        //Register Ambassador User
        private void RegisterAmbassador(RegisterVM registration)
        {
            try
            {
                //Create Ambassador
                Ambassador ambassador = new Ambassador();
                ambassador.AmbassadorType = new AmbassadorType { AmbassadorTypeId = Convert.ToInt32(registration.RegisterInfo.ambassadorType) };
                ambassador.AmbassadorTypeId = ambassador.AmbassadorType.AmbassadorTypeId;
                ambassador.Idnumber = registration.RegisterInfo.Idnumber;
                ambassador.Idphoto = registration.RegisterInfo.IDPhoto;
                ambassador.ProofOfAddress = null; //Amanda soloution
                ambassador.Motivation = registration.RegisterInfo.AboutMyself;

                ambassador.BankAccount = new BankAccount { AccountHolder = registration.bankAccount.AccountHolder, AccountTypeId = registration.bankAccount.AccountTypeId, BankId = registration.bankAccount.BankId, AccountNumber = Convert.ToInt64(registration.bankAccount.AccountNumber) };

                //Create User
                User user = new User();
                user.UserRole = new UserRole { UserRoleId = 2 };
                user.UserRoleId = user.UserRole.UserRoleId;
                user.Title = new Title { TitleId = registration.RegisterInfo.TitleID };
                user.TitleId = user.Title.TitleId;

                user.Name = registration.RegisterInfo.Name;
                user.Surname = registration.RegisterInfo.Surname;
                user.Email = registration.RegisterInfo.EmailAddress;
                user.UserName = registration.RegisterInfo.EmailAddress;
                user.NormalizedEmail = registration.RegisterInfo.EmailAddress.ToUpper();
                user.NormalizedUserName = registration.RegisterInfo.EmailAddress.ToUpper();
                user.PhoneNumber = registration.RegisterInfo.PhoneNumber;
                user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(registration.AccessInfo.Password);
                Password password = new Password { Password1 = BCrypt.Net.BCrypt.HashPassword(registration.AccessInfo.Password), UserId = user.UserId.ToString(), DateSet = DateTime.UtcNow };
                // UserApplicationStatus uAPP = new UserApplicationStatus { ApplicationStatusId = 1, UserId = user.UserId.ToString() };

                Application application = new Application { ApplicationStatusId = 1, UserId = user.Id };
                Address address = new Address { Address1 = registration.RegisterInfo.Address, City = registration.RegisterInfo.City, PostalCode = registration.RegisterInfo.PostalCode, CountryId = registration.RegisterInfo.CountryID, ProvinceId = registration.RegisterInfo.ProvinceID, UserId = user.Id, Country = new Country { CountryId = registration.RegisterInfo.CountryID } };
                db.Addresses.Add(address);
                user.Applications.Add(application);
                //user.Country = new Country { CountryId = registration.RegisterInfo.CountryID };
                //user.CountryId = user.Country.CountryId;
                //user.Address = new Address { Address1 = registration.RegisterInfo.Address, City = registration.RegisterInfo.City, PostalCode = registration.RegisterInfo.PostalCode };
                //user.AddressId = user.Address.AddressId;
                //User
                user.Ambassadors.Add(ambassador);
                ambassador.User = user;

                //Cart
                Cart cart = new Cart();
                cart.UserId = user.Id;
                Add(cart);

                //Ambassadortype
                ambassador.AmbassadorType.Ambassadors.Add(ambassador);
                ambassador.AmbassadorType = ambassador.AmbassadorType;

                //userrole
                user.UserRole.Users.Add(user);
                user.UserRole = user.UserRole;

                //title
                user.Title.Users.Add(user);
                user.Title = user.Title;

                //country
                //user.Country.Users.Add(user);
                //user.Country = user.Country;

                //userapplicationstatus
                //user.UserApplicationStatuses.Add(uAPP);
                //uAPP.User = user;

                //address
                //user.Address.Users.Add(user);
                //user.Address = user.Address;

                //password
                user.Passwords.Add(password);
                password.User = user;

                //Application status
                //user.UserApplicationStatuses.Add(uAPP);
                //uAPP.User = user;

                //Assignings
                //userrole
                db.Entry(user.UserRole).State = EntityState.Unchanged;
                //title
                db.Entry(user.Title).State = EntityState.Unchanged;
                //Country
                db.Entry(address.Country).State = EntityState.Unchanged;
                //Ambassador Type
                db.Entry(ambassador.AmbassadorType).State = EntityState.Unchanged;

                //add to database
                //db.UserApplicationStatuses.Add(uAPP);
                db.Applications.Add(application);
                db.Ambassadors.Add(ambassador);
                //db.SaveChanges();




            }
            catch (Exception error)
            {
                // return false;
            }
        }


        // testing 
        public bool ValidateRefferralCode(string refferalCode)
        {
            //see if there is a valid refferal code is used
            var registrationRefferralCode = db.ReferralCodes.Where(code => code.ReferralCode1 == refferalCode).FirstOrDefault();
            if (registrationRefferralCode == null)
            {
                return false;
            }

            //Refferal code exists
            else
            {
                return true;
            }
        }

        //Register Client user
        private void RegisterClient(RegisterVM registration)
        {

            //Create Client
            Client client = new Client();
            client.Ambassador = new Ambassador { AmbassadorId = Convert.ToInt32(FindRefferalLink(registration.RegisterInfo.referralcode)) };
            client.AmbassadorId = Convert.ToInt32(FindRefferalLink(registration.RegisterInfo.referralcode));

            //Create user
            User user = new User();
            client.UserId = user.UserId.ToString();
            user.UserRole = new UserRole { UserRoleId = 1 };
            user.UserRoleId = user.UserRole.UserRoleId;
            user.Title = new Title { TitleId = registration.RegisterInfo.TitleID };
            user.TitleId = user.Title.TitleId;
            //user.Country = new Country { CountryId = registration.RegisterInfo.CountryID };
            //user.CountryId = user.Country.CountryId;
            //user.Address = new Address { Address1 = registration.RegisterInfo.Address, City = registration.RegisterInfo.City, PostalCode = registration.RegisterInfo.PostalCode };
            //user.AddressId = user.Address.AddressId;
            user.Name = registration.RegisterInfo.Name;
            user.Surname = registration.RegisterInfo.Surname;
            // user.EmailAddress = registration.RegisterInfo.EmailAddress;
            user.Email = registration.RegisterInfo.EmailAddress;
            user.NormalizedEmail = registration.RegisterInfo.EmailAddress.ToUpper();
            user.NormalizedUserName = registration.RegisterInfo.EmailAddress.ToUpper();
            user.UserName = registration.RegisterInfo.EmailAddress;
            user.PhoneNumber = Convert.ToInt32(registration.RegisterInfo.PhoneNumber);
            user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(registration.AccessInfo.Password);
            Password password = new Password { Password1 = BCrypt.Net.BCrypt.HashPassword(registration.AccessInfo.Password), UserId = user.Id, DateSet = DateTime.UtcNow };
            //UserApplicationStatus uAPP = new UserApplicationStatus { ApplicationStatusId = 2, UserId = user.Id, Date = DateTime.Today };
            Application application = new Application { ApplicationStatusId = 2, UserId = user.Id };
            Address address = new Address { Address1 = registration.RegisterInfo.Address, City = registration.RegisterInfo.City, PostalCode = registration.RegisterInfo.PostalCode, CountryId = registration.RegisterInfo.CountryID, ProvinceId = registration.RegisterInfo.ProvinceID, UserId = user.Id, Country = new Country { CountryId = registration.RegisterInfo.CountryID } };
            db.Addresses.Add(address);
            user.Applications.Add(application);

            //Create their cart
            Cart cart = new Cart();
            cart.UserId = user.Id;
            Add(cart);

            //Link tables
            //Client
            user.Clients.Add(client);
            client.User = user;

            //userrole
            user.UserRole.Users.Add(user);
            user.UserRole = user.UserRole;

            //title
            user.Title.Users.Add(user);
            user.Title = user.Title;

            //country
            //user.Country.Users.Add(user);
            //user.Country = user.Country;

            //address
            //user.Address.Users.Add(user);
            //user.Address = user.Address;

            //password
            user.Passwords.Add(password);
            password.User = user;

            //Application status
            //user.UserApplicationStatuses.Add(uAPP);
            //uAPP.User = user;

            //Assign 
            //userrole
            db.Entry(user.UserRole).State = EntityState.Unchanged;
            //title
            db.Entry(user.Title).State = EntityState.Unchanged;
            //Country
            db.Entry(address.Country).State = EntityState.Unchanged;
            //ambassador
            db.Entry(client.Ambassador).State = EntityState.Unchanged;

            //add to database
            db.Applications.Add(application);
            db.Clients.Add(client);
            //db.SaveChanges();


            //link user to ambassador
            //LinkUsers(registration.RegisterInfo.referralcode, registration.RegisterInfo.EmailAddress, "Client");



        }

        public void CreateCourse(NewCourseVM course)
        {
            throw new NotImplementedException();
        }

        public string ytVideo(string link)
        {
            var positionStart = link.IndexOf("=");
            var videoID = link.Substring(positionStart + 1);
            return videoID;
        }

        public void GenerateAmbassadorsRefferral(RegisterVM registration, int ambassadorID)
        {
            //giving ambassador their refferal code
            ReferralCode code = new ReferralCode();
            code.AmbassadorId = ambassadorID;
            code.IsActive = "true";
            var newRefferalCode = GenerateRefferralCode(registration.RegisterInfo.Name, registration.RegisterInfo.Surname, registration.RegisterInfo.referralcode).ToString();
            var existingRefferalCode = db.ReferralCodes.Where(code => code.ReferralCode1 == newRefferalCode).FirstOrDefault();

            //if generated refferral code doesnt already exist
            if (existingRefferalCode == null)
            {
                code.ReferralCode1 = newRefferalCode;
                Add(code);
                //db.SaveChanges();
            }

            //if generated refferral code already exists
            if (existingRefferalCode != null)
            {
                code.ReferralCode1 = GenerateRefferralCode(registration.RegisterInfo.Name, registration.RegisterInfo.Surname, registration.RegisterInfo.referralcode).ToString();
                Add(code);
                //db.SaveChanges();
            }

            //Create a linkage between the users through refferral code
            //LinkUsers(registration.RegisterInfo.referralcode, registration.RegisterInfo.EmailAddress, "Ambassador");
        }


        public void LinkUsers(string refferalCode, string emailaddress, int usertype)
        {
            var refferalrecord = db.ReferralCodes.Where(refferalcode => refferalcode.ReferralCode1 == refferalCode).FirstOrDefault();

            if (usertype == 1)
            {

                Referral linking = new Referral();
                linking.ReferralCodeId = refferalrecord.ReferralCodeId;
                linking.ReferralLinkTypeId = 1;
                linking.Date = DateTime.Now;
                var userId = db.Users.Where(email => email.Email == emailaddress).Select(userid => userid.Id).ToList();
                linking.UserId = userId[0];
                Add(linking);
                //SaveChanges();
                //return true;
            }
            if (usertype == 2)
            {
                Referral linking = new Referral();
                linking.ReferralCodeId = refferalrecord.ReferralCodeId;
                linking.ReferralLinkTypeId = 2;
                linking.Date = DateTime.Now;
                var userId = db.Users.Where(email => email.Email == emailaddress).Select(userid => userid.Id).ToList();
                linking.UserId = userId[0];
                Add(linking);
                //SaveChanges();
                //return true;
            }
            else
            {
                //return false;
            }




        }

        //Getting all admin users
        public object GetAllAdmins()
        {
            try
            {
                var adminlist = db.Admins.Include(user => user.User)
                                             //.ThenInclude(country => country.Country)
                                             .Include(user => user.User)
                                             //.ThenInclude(address => address.Address)
                                             .Include(user => user.User)
                                            .ThenInclude(password => password.Passwords)
                                            .Include(user => user.User)
                                            .ThenInclude(title => title.Title)
                                            .Include(user => user.User)
                                            .ThenInclude(userrole => userrole.UserRole);
                return adminlist;
            }
            catch (Exception error)
            {
                return error.InnerException.Message;
            }
        }

        //Get all ambassador users
        public object GetAllAmbassadors()
        {
            try
            {
                var ambassadorList = db.Ambassadors.Include(user => user.User)
                                             //.ThenInclude(country => country.Country)
                                             .Include(user => user.User)
                                             // .ThenInclude(address => address.Address)
                                             .Include(user => user.User)
                                            .ThenInclude(password => password.Passwords)
                                            .Include(user => user.User)
                                            .ThenInclude(title => title.Title)
                                            .Include(user => user.User)
                                            .ThenInclude(userrole => userrole.UserRole)
                                            .ThenInclude(access => access.AccessLevel);

                return ambassadorList;
            }
            catch (Exception error)
            {
                return error.InnerException.Message;
            }
        }

        //Get all client users
        public object GetAllClients()
        {
            try
            {
                var clientList = db.Clients.Include(user => user.User)
                                             //.ThenInclude(country => country.Country)
                                             .Include(user => user.User)
                                             //.ThenInclude(address => address.Address)
                                             .Include(user => user.User)
                                            .ThenInclude(password => password.Passwords)
                                            .Include(user => user.User)
                                            .ThenInclude(title => title.Title)
                                            .Include(user => user.User)
                                            .ThenInclude(userrole => userrole.UserRole)
                                            .ThenInclude(access => access.AccessLevel)
                                            .Include(user => user.User)
                                            .ThenInclude(clients => clients.Clients);
                return clientList;
            }
            catch (Exception error)
            {
                return error.InnerException.Message;
            }
        }

        //Get session information
        public object getUserSessionInfo(LoginVM logindetails)
        {
            try
            {
                var user = db.Users.Where(user => user.UserName == logindetails.EmailorUsername || user.Email == logindetails.EmailorUsername)
                                                                        .Include(address => address.Addresses)
                                                                        .ThenInclude(country => country.Country)
                                                                        .Include(title => title.Title)
                                                                        .Include(userrole => userrole.UserRole)
                                                                        .Include(refferral => refferral.Referrals)
                                                                        .ThenInclude(code => code.ReferralCode)
                                                                        .Include(address => address.Addresses)
                                                                        .ThenInclude(province => province.Province)
                                                                        .Include(amb => amb.Ambassadors)
                                                                        .ThenInclude(bankacc => bankacc.BankAccount)
                                                                        .ThenInclude(acc => acc.AccountType)
                                                                        .Include(amb => amb.Ambassadors)
                                                                        .ThenInclude(bankacc => bankacc.BankAccount)
                                                                        .ThenInclude(b => b.Bank)
                                                                        .FirstOrDefault();
                if (user == null)
                {
                    return "User doesnt exist";
                }
                else
                {
                    return user;
                }
            }
            catch (Exception error)
            {
                return error.InnerException.Message;
            }
        }

        public object ApplicationStatus(string id)
        {
            //find users application and return that object
            var applicationStatus = db.Applications.Where(user => user.UserId == id).Include(status => status.ApplicationStatus).ToList();
            return applicationStatus;
        }

        //Get all the titles on the system
        public object GetTitles()
        {
            try
            {
                var titles = db.Titles.ToList();
                return titles;
            }
            catch (Exception error)
            {
                return error.Message;
            }
        }

        //Get all teh countries available on the system
        public object GetCountry()
        {
            try
            {
                var countries = db.Countries.ToList();
                return countries;
            }
            catch (Exception error)
            {
                return error.Message;
            }
        }

        //Get all user roles
        public object GetUserRoles()
        {
            try
            {
                var userroles = db.UserRoles.ToList();
                return userroles;
            }
            catch (Exception error)
            {
                return error.Message;
            }
        }

        //Get all the ambassador types
        public object GetAmbassadorTypes()
        {
            try
            {
                var ambassadorTypeList = db.AmbassadorTypes;
                return ambassadorTypeList.ToList();
            }
            catch (Exception error)
            {
                return error.Message;
            }
        }

        //Get specific feedback
        public object FindFeedback(int id)
        {
            try
            {
                Feedback feedback = db.Feedbacks.Where(x => x.FeedbackId == id).Single<Feedback>();
                return feedback;
            }
            catch (Exception error)
            {
                return error.InnerException.Message;
            }
        }

        //Get all product feedbacks
        //public object GetProductFeedbacks()
        //{
        //    try
        //    {
        //        var productfeedbacks = db.Feedbacks.Include(prod => prod.Product).Include(prodtype => prodtype.Product.ProductType).ToList();
        //        var FeedbackList = (from f in db.Feedbacks
        //                            join p in db.Products on f.ProductId equals p.ProductId
        //                            join pt in db.ProductTypes on p.ProductTypeId equals pt.ProductTypeId
        //                            select new
        //                            {
        //                                f.FeedbackId,
        //                                f.FeedbackTypeId,
        //                                f.Description,
        //                                f.Date,
        //                                f.ClientId,
        //                                p.ProductName,
        //                                pt.ProductTypeName
        //                            });
        //        return FeedbackList;
        //    }
        //    catch (Exception error)
        //    {
        //        return error.InnerException.Message;
        //    }
        //}

        //Get all ambassador feedbacks
        //public object GetAmbassadorFeedbacks()
        //{
        //    try
        //    {
        //        var ambassadorFeedback = db.Feedbacks.Include(amb => amb.Ambassador).Include(user=>user.Client);
        //        var FeedbackList = (from f in db.Feedbacks
        //                            join a in db.Ambassadors on f.AmbassadorId equals a.AmbassadorId
        //                            join u in db.Users on a.UserId equals u.UserId
        //                            select new
        //                            {
        //                                f.FeedbackId,
        //                                f.FeedbackTypeId,
        //                                f.Description,
        //                                f.Date,
        //                                f.ClientId,
        //                                u.Name,
        //                                u.Surname

        //                            }).ToList();
        //        return FeedbackList;
        //    }
        //    catch (Exception error)
        //    {
        //        return error.InnerException.Message;
        //    }
        //}

        //Get all FAQs of the account category
        //public object GetAccountFAQs()
        //{
        //    try
        //    {
        //        var FAQList = db.Faqs.Where(x => x.Faqcategory.CategoryName == "Account").ToList();
        //        return FAQList;
        //    }
        //    catch (Exception error)
        //    {
        //        return error.InnerException.Message;
        //    }
        //}

        //Get all FAQs of the product category
        //public object GetProductFAQs()
        //{
        //    try
        //    {
        //        var FAQList = db.Faqs.Where(x => x.Faqcategory.CategoryName == "Product").ToList();
        //        return FAQList;
        //    }
        //    catch (Exception error)
        //    {
        //        return error.InnerException.Message;
        //    }
        //}

        //Get all FAQs of the delivery category
        //public object GetDeliveryFAQs()
        //{
        //    try
        //    {
        //        var FAQList = db.Faqs.Where(x => x.Faqcategory.CategoryName == "Delivery").ToList();
        //        return FAQList;
        //    }
        //    catch (Exception error)
        //    {
        //        return error.InnerException.Message;
        //    }
        //}

        //Get ambassador assigned to users information
        public object MyAmbassador(int id)
        {
            try
            {
                var ambassador = db.Ambassadors
                                .Include(user => user.User)
                                .Include(client => client.Clients)
                                .Include(user => user.User)
                                //.ThenInclude(address => address.Address)
                                .Include(user => user.User)
                                //.ThenInclude(country => country.Country)
                                .Include(fb => fb.Feedbacks).Where(x => x.AmbassadorId == id);
                return ambassador;
            }
            catch (Exception error)
            {
                return error.InnerException.Message;
            }
        }

        //Get Catalog by category
        //public object GetCatalogByCategory(int id)
        //{
        //    try
        //    {
        //        var categoryproducts = db.Products.Where(prod => prod.ProductTypeId == id).ToList();
        //        var CategoryCatalog = (from a in db.Products
        //                               join b in db.ProductPrices on a.ProductId equals b.ProductId
        //                               join c in db.Prices on b.PriceId equals c.PriceId
        //                               select new
        //                               {
        //                                   a.ProductId,
        //                                   //a.SpecialId,
        //                                   a.ProductTypeId,
        //                                   a.Description,
        //                                   //a.Quantity,
        //                                   a.ProductName,
        //                                   //ProductImage = Convert.ToBase64String(a.ProductImage),
        //                                   c.Price1
        //                               }).Where(x => x.ProductTypeId == id).ToList();
        //        return categoryproducts;

        //    }
        //    catch (Exception error)
        //    {
        //        return error.InnerException.Message;
        //    }

        //}

        public void DontModify<T>(T entity) where T : class
        {
            db.Entry(entity).State = EntityState.Unchanged;
        }

        public object GetFAQCategories()
        {
            var categories = db.Faqcategories.ToList();
            return categories;
        }

        public bool updateFAQ(Faq faq)
        {
            try
            {
                Faq existingFaq = db.Faqs.Where(faqid => faqid.Faqid == faq.Faqid).FirstOrDefault();
                existingFaq.Faqquestion = faq.Faqquestion;
                //existingFaq.FaqtypeId = faq.FaqtypeId;
                existingFaq.FaqcategoryId = faq.FaqcategoryId;
                existingFaq.Faqanswers = faq.Faqanswers;
                return true;
            }
            catch
            {
                return false;
            }
        }

        //Amandas Repository Code
        /// <summary>
        ////////////////////////////////// AMANDA CODE /////////////////////////////
        /// </summary>
        public object GetSecondaryAddress(string id)
        {
            try
            {
                var userAdresses = db.Addresses.Where(x => x.UserId == id).Select(x => new
                {
                    Id = x.AddressId,
                    Address = x.Address1,
                    Country = x.Country.CountryName,
                    Province = x.Province.ProvinceName,
                    City = x.City,
                    PostalCode = x.PostalCode,
                    Phone = x.RecipientNumber
                });

                return userAdresses;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object GetSecondaryAddressById(int id)
        {
            try
            {
                var userAdresses = db.Addresses.Where(x => x.AddressId == id).Select(x => new
                {
                    Id = x.AddressId,
                    Address = x.Address1,
                    CountryId = x.CountryId,
                    ProvinceId = x.ProvinceId,
                    City = x.City,
                    PostalCode = x.PostalCode,
                    Phone = x.RecipientNumber
                }).FirstOrDefault();

                return userAdresses;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object AddSecondaryAddress(Address address)
        {

            Address nAddress = db.Addresses.Where(x => x.UserId == address.UserId && x.Address1 == address.Address1).FirstOrDefault();

            try
            {
                if (nAddress == null)
                {
                    nAddress = new Address()
                    {
                        Address1 = address.Address1,
                        City = address.City,
                        ProvinceId = address.ProvinceId,
                        CountryId = address.CountryId,
                        UserId = address.UserId,
                        RecipientNumber = address.RecipientNumber,
                        PostalCode = address.PostalCode
                    };
                    Add(nAddress);
                    SaveChanges();

                    return "New Address created";
                }
                else
                {
                    return "Exists";
                }


            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object EditSecondaryAddress(Address address)
        {
            try
            {
                //find the item by id
                Address nAddress = db.Addresses.FirstOrDefault(x => x.AddressId == address.AddressId);

                // make the replacements
                nAddress.Address1 = address.Address1;
                nAddress.City = address.City;
                nAddress.ProvinceId = address.ProvinceId;
                nAddress.CountryId = address.CountryId;
                nAddress.UserId = address.UserId;
                nAddress.RecipientNumber = address.RecipientNumber;
                nAddress.PostalCode = address.PostalCode;
                SaveChanges();

                return "true";
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object DeleteSecondaryAddress(int id)
        {
            try
            {
                //Delete item
                var address = db.Addresses.Find(id);
                Delete(address);
                SaveChanges();
                return true;

            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object CreateMerch(MerchVM merch)
        {
            //Check if item exists
            Merchandise newMerch = db.Merchandises.FirstOrDefault(m => m.MerchName == merch.MerchName);

          
                //create item if null
                if (newMerch == null)
                {
                    newMerch = new Merchandise()
                    {
                        MerchName = merch.MerchName,
                        Description = merch.Description,
                        MerchImage = merch.MerchImage,
                        MerchStatusId = merch.StatusId,
                        MerchTypeId = merch.MerchTypeId,
                        MerchCategoryId = merch.MerchCategoryId

                    };
                    Add(newMerch);
                SaveChanges();
                    //await db.SaveChangesAsync(id);

                    //Create new price if null
                    // Need to make sure that the price isn't attached to any other ID
                    Price searchPrice = db.Prices.FirstOrDefault(p => p.Price1 == merch.Price && p.MerchandiseId == newMerch.MerchandiseId);

                    if (searchPrice == null)
                    {
                        Price price = new()
                        {
                            Price1 = merch.Price,
                            Date = DateTime.Now,
                            MerchandiseId = newMerch.MerchandiseId
                        };
                        Add(price);
                    SaveChanges();
                    //await db.SaveChangesAsync(id);
                }


                    return "Item Created";

                }
                else
                {
                    return "Item Exist";
                }


        }

        public object UpdateMerch(int id, MerchVM merch)
        {
            try
            {
                //find the item by id
                Merchandise eMerch = db.Merchandises.FirstOrDefault(m => m.MerchandiseId == id);

                // make the replacements 
                eMerch.MerchName = merch.MerchName;
                eMerch.Description = merch.Description;
                eMerch.MerchImage = merch.MerchImage ?? eMerch.MerchImage;
                eMerch.MerchStatusId = merch.StatusId;
                eMerch.MerchTypeId = merch.MerchTypeId;
                eMerch.MerchCategoryId = merch.MerchCategoryId;
                SaveChanges();

                //Create new price if null
                //Thats it there is no mathing price for that id
                Price searchPrice = db.Prices.FirstOrDefault(p => p.Price1 == merch.Price && p.MerchandiseId == id);

                if (searchPrice == null)
                {
                    Price price = new()
                    {
                        Price1 = merch.Price,
                        Date = DateTime.Now,
                        MerchandiseId = eMerch.MerchandiseId
                    };
                    Add(price);
                    SaveChanges();
                }

                return "Item Updated successfully";
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object DeleteMerch(int id)
        {
            try
            {
                
                //Delete item
                var merch = db.Merchandises.Find(id);
                var lookInCart = db.CartItems.Where(x => x.MerchandiseId == merch.MerchandiseId);
                var lookInOrder = db.OrderItems.Where(x => x.MerchandiseId == merch.MerchandiseId);
                var special = db.MerchSpecials.Where(x => x.MerchandiseId == merch.MerchandiseId);

                if (lookInCart == null || lookInOrder == null || special == null)
                {
                    Delete(merch);
                    //Delete associated prices
                    db.Prices.RemoveRange(db.Prices.Where(p => p.MerchandiseId == id));
                    SaveChanges();

                    return "Item Deleted";
                }
                else
                {
                    var status = db.MerchStatuses.Where(x => x.MerchStatusName == "Out of Stock").First();
                    merch.MerchStatusId = status.MerchStatusId;
                    SaveChanges();
                    return "Status Updated";
                }
                
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object GetAllMerch()
        {
            try
            {
                var allMerch = db.Merchandises
                    .Select(x => new
                    {
                        ID = x.MerchandiseId,
                        Name = x.MerchName,
                        Description = x.Description,
                        Image = x.MerchImage,
                        Type = x.MerchType.MerchTypeName,
                        TypeID = x.MerchTypeId,
                        CatID = x.MerchCategoryId,
                        Category = x.MerchCategory.MerchCategoryName,
                        Price = x.Prices.OrderByDescending(o => o.Date).Select(p => p.Price1).FirstOrDefault(),
                        Status = x.MerchStatuses.MerchStatusName,
                        Quantity = 0
                    });

                return allMerch;
            }
            catch
            {
                return false;
            }
        }

        //public object GetAllMerchBySearch()
        //{
        //    try
        //    {
        //        var allMerch = from m in db.Merchandises
        //            where (type == null || m.MerchTypeId == type) && (category == null || m.MerchCategoryId == category)
        //            Select new
        //            {
        //                ID = x.MerchandiseId,
        //                Name = x.MerchName,
        //                Description = x.Description,
        //                Image = x.MerchImage,
        //                Type = x.MerchType.MerchTypeName,
        //                TypeID = x.MerchTypeId,
        //                CatID = x.MerchCategoryId,
        //                Category = x.MerchCategory.MerchCategoryName,
        //                Price = x.Prices.OrderByDescending(o => o.Date).Select(p => p.Price1).FirstOrDefault(),
        //                Status = x.MerchStatuses.MerchStatusName,
        //                Quantity = 0
        //            });

        //        return allMerch;
        //    }
        //    catch
        //    {
        //        return false;
        //    }
        //}

        public object GetMerchById(int id)
        {
            try
            {
                var merch = db.Merchandises.Where(m => m.MerchandiseId == id).Select(x => new
                {
                    ID = x.MerchandiseId,
                    Name = x.MerchName,
                    Description = x.Description,
                    Image = x.MerchImage,
                    Type = x.MerchType.MerchTypeName,
                    TypeID = x.MerchTypeId,
                    CatID = x.MerchCategoryId,
                    Category = x.MerchCategory.MerchCategoryName,
                    Price = x.Prices.Select(p => p.Price1).First(),
                    Status = x.MerchStatuses.MerchStatusId,
                    Quantity = 0
                }).FirstOrDefault();

                return merch;
            }
            catch
            {
                return false;
            }
        }

        public object AmbassadorDiscount(string id)
        {
            //Fetch ambassador discount
            var varID = id;
            var discount = db.Ambassadors.Where(id => id.UserId == varID)
                                        .Select(x => new { Discount = x.AmbassadorType.DiscountPercentage });
            return discount;
        }

        public object GetVAT()
        {
            var VATAmount = db.Vats.OrderByDescending(x => x.Date).Select(x =>new {Id =x.Vatid, Amount= x.VatPercentage }).FirstOrDefault();

            return VATAmount;
        }

        public object UpdateVAT(int id, decimal amount)
        {
            try
            {
                var VATAmount = db.Vats.FirstOrDefault(x => x.Vatid == id);
                VATAmount.VatPercentage = amount;
                SaveChanges();

                return "Amount Updated";
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object AddToCart(string id, CartItem cartitem)
        {
            //Find the cart for the specific user
            Cart userCartID = db.Carts.FirstOrDefault(c => c.UserId == id);

            try
            {
                if (cartitem.MerchandiseId != null)
                {
                    return AddMerchToCart(userCartID.CartId, cartitem);
                }
                else
                {
                    return AddSpecialToCart(userCartID.CartId, cartitem);
                }
               
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }

        }

        public object AddMerchToCart(int id, CartItem cartitem)
        {
            try
            {
                CartItem merch = db.CartItems.FirstOrDefault(x => x.CartId == id && x.MerchandiseId == cartitem.MerchandiseId);

                if (merch == null)
                {
                    var spCat = db.MerchSpecials
                            .Where(x => x.MerchandiseId == cartitem.MerchandiseId && x.SpecialCategoryId == 1)
                            .Select(x => new { MerchId = x.MerchandiseId, MerchPrice = x.Special.Price }).FirstOrDefault();

                    CartItem cart = new CartItem();
                    cart.CartId = id;
                    cart.Quantity = cartitem.Quantity;

                    if (spCat == null)
                    {
                        cart.Price = cartitem.Price;
                        cart.MerchandiseId = cartitem.MerchandiseId;
                    }
                    else
                    {
                        cart.MerchandiseId = spCat.MerchId;
                        cart.Price = spCat.MerchPrice;
                    }

                    Add(cart);
                    SaveChanges();
                    return "Added To Cart";
                }
                else
                {

                    merch.Quantity += cartitem.Quantity;
                    SaveChanges();
                    return "Item Updated";
                }
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }


        public object AddSpecialToCart(int id, CartItem cartitem)
        {
            try
            {
                CartItem sp = db.CartItems.FirstOrDefault(x => x.CartId == id && x.SpecialId == cartitem.SpecialId);

                if (sp == null)
                {
                    //var spCat = db.MerchSpecials.FirstOrDefault(x => x.SpecialId == cartitem.SpecialId);


                    CartItem cart = new CartItem();
                    cart.CartId = id;
                    cart.SpecialId = cartitem.SpecialId;
                    cart.Price = cartitem.Price;
                    cart.Quantity = cartitem.Quantity;

                    Add(cart);
                    SaveChanges();
                    return "Added To Cart";
                }
                else
                {

                    sp.Quantity += cartitem.Quantity;
                    SaveChanges();
                    return "Item Updated";
                }

            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object loadCart(string id)
        {
            //Find the cart for the specific user
            Cart userCartID = db.Carts.FirstOrDefault(c => c.UserId == id);

            try
            {
                var loadcart = db.CartItems.Where(x => x.CartId == userCartID.CartId).Select(x => new
                {
                    Id = x.CartItemId,
                    CartId = x.CartId,
                    Price = x.Price,
                    Quantity = x.Quantity,
                    Name = x.Merchandise.MerchName ?? x.Special.SpecialName,
                    Image = x.Merchandise.MerchImage ?? x.Special.SpecialImage
                });

                return loadcart;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object increaseCartItem(int id)
        {
            try
            {
                var item = db.CartItems.Find(id);
                item.Quantity += 1;
                SaveChanges();

                return "Item increased";
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object decreaseCartItem(int id)
        {
            try
            {
                var item = db.CartItems.Find(id);

                if (item.Quantity > 1)
                {
                    item.Quantity -= 1;
                    SaveChanges();

                    return "Item decreased";
                }
                else
                {
                    return "Item already at 1";
                }

            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }


        public object RemoveFromCart(int itemID)
        {
            var item = FindById<CartItem>(itemID);
            Delete(item);
            SaveChanges();
            return "Item removed";

        }


        public object ClearCart(int cartID)
        {
            db.CartItems.RemoveRange(db.CartItems.Where(c => c.CartId == cartID));
            SaveChanges();
            return "Cart cleared";
        }

        public object Checkout(Order checkout)
        {
            try
            {
                //Find the cart for the specific user
                Cart userCartID = db.Carts.FirstOrDefault(c => c.UserId == checkout.UserId);
               // User EmailClient = db.Users.FirstOrDefault(c => c.Id == checkout.UserId);

                Delivery delivery = new Delivery();
                if (checkout.AddressId != null)
                {
                    delivery.DeliveryAmountId = 1;
                    Add(delivery);
                    SaveChanges();
                }


                //Get associated ambassador
                Referral referfalCode = db.Referrals.FirstOrDefault(x => x.UserId == checkout.UserId);
                var AssociatedAmbassador = db.ReferralCodes.FirstOrDefault(x => x.ReferralCodeId == referfalCode.ReferralCodeId);
               // User EmailAmb = db.Users.FirstOrDefault(c => c.Id == AssociatedAmbassador.Ambassador.UserId);

                Order newOrder = new Order();
                newOrder.OrderStatusId = checkout.OrderStatusId;
                newOrder.AddressId = checkout.AddressId;
                newOrder.CartId = userCartID.CartId;
                newOrder.UserId = checkout.UserId;
                newOrder.DeliveryId = checkout.AddressId == null ? null : delivery.DeliveryId;
                newOrder.ProofOfPayment = checkout.ProofOfPayment;
                newOrder.Date = DateTime.Today;
                newOrder.AmbassadorId = AssociatedAmbassador.AmbassadorId ?? null;
                Add(newOrder);
                SaveChanges();


                var cart = db.CartItems.Where(x => x.CartId == userCartID.CartId);
                foreach (var item in cart)
                {
                    OrderItem items = new OrderItem();
                    items.MerchandiseId = item.MerchandiseId ?? null;
                    items.SpecialId = item.SpecialId ?? null;
                    items.OrderId = newOrder.OrderId;
                    items.Quantity = item.Quantity;
                    items.Price = item.Price;
                    Add(items);
                }
                SaveChanges();

                

               // string Clientmessage = "Thanks For Shoppin With SAICS! Your order Will be processed soon!";
                //this.CheckoutEmail(EmailClient.Email, "Order Received", EmailClient.Email, Clientmessage);
                

               // string AmbassadorMessage = $"Order #{newOrder.OrderId} has been placed by {userCartID.User.Name}  {userCartID.User.Surname}";
              //  this.CheckoutEmail(EmailAmb.Email, "New Order", EmailAmb.Email, AmbassadorMessage);

                ClearCart(userCartID.CartId);
                return "Order Placed";
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }

        }

        public object ViewOrderHistory(string userID)
        {
            try
            {
                var orders = db.Orders.Where(id => id.UserId == userID)
                                 .Select(x => new
                                 {
                                     Id = x.OrderId,
                                     Date = x.Date,
                                     Status = x.OrderStatus.OrderStatusName,
                                     Amount = x.OrderItems.Sum(x => x.Price * x.Quantity),
                                     //Quantity = x.OrderItems.Select(x => x.Quantity),
                                 });
                return orders;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }

        }

        public object ViewOrderDetails(int orderID)
        {
            try
            {
                var orderItem = db.Orders.Where(items => items.OrderId == orderID).Select(x => new
                {
                    Id = x.OrderId,
                    Status = x.OrderStatus.OrderStatusName,
                    Delivery = x.DeliveryId,
                    OrderItems = x.OrderItems.Select(x =>
                    new
                    {
                        Name = x.Merchandise.MerchName ?? x.Special.SpecialName,
                        Quantity = x.Quantity,
                        Price = x.Price
                    })

                }).FirstOrDefault();

                return orderItem;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }

        }


        public object GetSpecialOptions()
        {
            try
            {
                var options = db.Merchandises.Select(x => new
                {
                    Item = x.MerchImage,
                    Name = x.MerchName,
                    Status = x.MerchStatuses.MerchStatusName
                });

                return options;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object GetSpecialTypes()
        {
            try
            {
                var types = db.SpecialTypes.Select(x => new { Id = x.SpecialTypeId, Type = x.SpecialTypeName });
                return types;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object GetAllSpecials()
        {
            try
            {
                var res = db.Specials.Select(x => new
                {
                    Id = x.SpecialId,
                    Name = x.SpecialName,
                    Image = x.SpecialImage,
                    Price = x.Price,
                    Description = x.Description,
                    Type = x.SpecialType.SpecialTypeName,
                    TypeId = x.SpecialTypeId,
                    StartDate = x.StartDate,
                    EndDate = x.StartDate,
                    SpecialCategory = x.MerchSpecials.Select(x => x.SpecialCategoryId).FirstOrDefault(),
                    Quantity = 0

                });
                return res;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object GetSpecialById(int id)
        {

            try
            {
                var special = db.Specials.Where(x => x.SpecialId == id).Select(x => new
                {
                    Name = x.SpecialName,
                    TypeId = x.SpecialTypeId,
                    Price = x.Price,
                    StartDate = x.StartDate,
                    EndDate = x.EndDate,
                    Description = x.Description,
                    Merchandise = x.MerchSpecials.Select(x => x.Merchandise.MerchName).ToList()

                }).FirstOrDefault();
                return special;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object addSpecial(SpecialVM vm)
        {
            //Check if item exists
            Special nSpecial = db.Specials.FirstOrDefault(m => m.SpecialName == vm.Special.SpecialName);


            try
            {
                if (nSpecial == null)
                {
                    nSpecial = new Special()
                    {
                        SpecialName = vm.Special.SpecialName,
                        Description = vm.Special.Description,
                        SpecialImage = vm.Special.SpecialImage,
                        SpecialTypeId = vm.Special.SpecialTypeId,
                        Price = vm.Special.Price,
                        StartDate = vm.Special.StartDate,
                        EndDate = vm.Special.EndDate

                    };
                    Add(nSpecial);
                    SaveChanges();

                    foreach (var i in vm.SpecialItems)
                    {
                        //look for the merchIDs
                        Merchandise item = db.Merchandises.FirstOrDefault(m => m.MerchName == i.Name);

                        MerchSpecial MS = new MerchSpecial();
                        MS.SpecialId = nSpecial.SpecialId;
                        MS.MerchandiseId = item.MerchandiseId;
                        MS.SpecialCategoryId = vm.SpecialItems.Length == 1 ? 1 : 2;
                        Add(MS);
                    }
                    SaveChanges();

                    return "Special Created";

                }
                else
                {
                    return "Special Already Exists";
                }




            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object UpdateSpecial(SpecialVM vm)
        {
            try
            {
                //find Id
                Special eSpecial = db.Specials.FirstOrDefault(x => x.SpecialId == vm.Special.SpecialId);

                //Make replacements 
                eSpecial.SpecialName = vm.Special.SpecialName;
                eSpecial.SpecialTypeId = vm.Special.SpecialTypeId;
                eSpecial.SpecialImage = vm.Special.SpecialImage ?? eSpecial.SpecialImage;
                eSpecial.Description = vm.Special.Description;
                eSpecial.Price = vm.Special.Price;
                eSpecial.StartDate = vm.Special.StartDate;
                eSpecial.EndDate = vm.Special.EndDate;
                SaveChanges();

                //Clear and add the MerchSpecial
                db.MerchSpecials.RemoveRange(db.MerchSpecials.Where(x => x.SpecialId == eSpecial.SpecialId));
                foreach (var i in vm.SpecialItems)
                {
                    Merchandise item = db.Merchandises.FirstOrDefault(m => m.MerchName == i.Name);

                    MerchSpecial MS = new MerchSpecial();
                    MS.SpecialId = eSpecial.SpecialId;
                    MS.MerchandiseId = item.MerchandiseId;
                    MS.SpecialCategoryId = vm.SpecialItems.Length == 1 ? 1 : 2;
                    Add(MS);
                }
                SaveChanges();

                return "Special updated";
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object DeleteSpecial(int id)
        {
            try
            {

                var special = db.Specials.Find(id);
                var lookInCart = db.CartItems.Where(x => x.SpecialId == special.SpecialId).FirstOrDefault();
                var lookInOrder = db.OrderItems.Where(x => x.SpecialId == special.SpecialId).FirstOrDefault();

                if (lookInCart == null || lookInOrder == null)
                {
                    Delete(special);

                    db.MerchSpecials.RemoveRange(db.MerchSpecials.Where(x => x.SpecialId == id));
                    SaveChanges();

                    return "Special Deleted";
                }
                else
                {
                    
                  
                    return "Disable Special";
                }

            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object AgentAccountInfo(string id)
        {
            try
            {
                //Get asscociated ambassador
                Referral referfalCode = db.Referrals.FirstOrDefault(x => x.UserId == id);
                var AssociatedAmbassador = db.ReferralCodes.FirstOrDefault(x => x.ReferralCodeId == referfalCode.ReferralCodeId);

                var AmbassadorInfo = db.Ambassadors.Where(x => x.AmbassadorId == AssociatedAmbassador.AmbassadorId).Select(x => new
                {
                    Name = $"{x.User.Name} {x.User.Surname}",
                    BankName = x.BankAccount.Bank.BankName,
                    AccNumber = x.BankAccount.AccountNumber,
                    AccType = x.BankAccount.AccountType.AccountTypeName
                }).First();
                return AmbassadorInfo;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }


        //Client Subsystem//

        public object GetAssociatedAmbassador(string userId)
        {
            try
            {
                Referral referfalCode = db.Referrals.FirstOrDefault(x => x.UserId == userId);
                var AssociatedAmbassador = db.ReferralCodes.FirstOrDefault(x => x.ReferralCodeId == referfalCode.ReferralCodeId);

                var AmbassadorInfo = db.Ambassadors.Where(x => x.AmbassadorId == AssociatedAmbassador.AmbassadorId)
                                       .Select(x => new
                                       {
                                           Id = x.AmbassadorId,
                                           Ranking = x.AmbassadorType.AmbassadorTypeName,
                                           Title = x.User.Title.TitleName,
                                           Name = $"{x.User.Name} {x.User.Surname}",
                                           Alias = x.AliasName,
                                           Email = x.User.Email,
                                           Address = x.User.Addresses
                                           .Select(x => new
                                           {
                                               Country = x.Country.CountryName,
                                               City = x.City,
                                               Province = x.Province.ProvinceName,
                                               Phone = x.RecipientNumber,
                                               Address = x.Address1,
                                               Code = x.PostalCode

                                           }).First()

                                       }).FirstOrDefault();

                return AmbassadorInfo;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object PurchasedProducts(string userId)
        {

            try
            {
                var orders = db.Orders.Join(db.OrderItems, o => o.OrderId, i => i.OrderId,
                    (o, i) => new { o, i })
                    .Where(id => id.o.UserId == userId)
                    .Select(x => new { Id = x.i.MerchandiseId, Name = x.i.Merchandise.MerchName, Category = x.i.Merchandise.MerchCategoryId }).Distinct();

                return orders;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public bool AddFeedback(string userId, Feedback feedback)
        {


            Client client = db.Clients.FirstOrDefault(x => x.UserId == userId);

            Feedback newFeedBack = new Feedback
            {
                Description = feedback.Description,
                MerchandiseId = feedback.MerchandiseId ?? null,
                FeedbackTypeId = feedback.FeedbackTypeId,
                ClientId = client.ClientId,
                AmbassadorId = feedback.AmbassadorId ?? null,
                Date = DateTime.Now

            };
            Add(newFeedBack);
            //SaveChanges();

            return true;

        }

        public object GetAmbassadorFeedbacks(string userId)
        {

            try
            {
                Client client = db.Clients.FirstOrDefault(x => x.UserId == userId);
                var Feedback = db.Feedbacks.Where(x => x.ClientId == client.ClientId && x.FeedbackTypeId == 2).Select(x =>
                new
                {

                    Id = x.FeedbackId,
                    Description = x.Description, 
                    Name = $"{x.Ambassador.User.Name} {x.Ambassador.User.Surname}",
                    Date = x.Date,

                });
                return Feedback;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object GetProductFeedbacks(string userId)
        {

            try
            {
                Client client = db.Clients.FirstOrDefault(x => x.UserId == userId);
                var Feedback = db.Feedbacks.Where(x => x.ClientId == client.ClientId && x.FeedbackTypeId == 1).Select(x =>
                new
                {

                    Id = x.FeedbackId,
                    Description = x.Description,
                    Date = x.Date,
                    Category = x.Merchandise.MerchCategory.MerchCategoryName,
                    Name = x.Merchandise.MerchName

                });
                return Feedback;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public bool DeleteFeedback(int id)
        {

            var item = db.Feedbacks.Find(id);
                Delete(item);
                return true;
        }

        public object ViewClientFAQ(string userId)
        {

            try
            {
                return " ";
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }

        public object ViewCatalog()
        {
            try
            {
                var allMerch = db.Merchandises.Where(x => x.MerchStatuses.MerchStatusName == "In Stock")
                    .Select(x => new
                    {
                        ID = x.MerchandiseId,
                        Name = x.MerchName,
                        Description = x.Description,
                        Image = x.MerchImage,
                        Type = x.MerchType.MerchTypeName,
                        TypeID = x.MerchTypeId,
                        CatID = x.MerchCategoryId,
                        Category = x.MerchCategory.MerchCategoryName,
                        Price = x.Prices.OrderByDescending(o => o.Date).Select(p => p.Price1).FirstOrDefault(),
                        Status = x.MerchStatuses.MerchStatusName,
                        Quantity = 0
                    });

                return allMerch;
            }
            catch
            {
                return false;
            }
        }

        public object ViewCatalogItem(int id)
        {
            var allMerch = db.Merchandises.Where(x => x.MerchandiseId == id)
                   .Select(x => new
                   {
                       ID = x.MerchandiseId,
                       Name = x.MerchName,
                       Description = x.Description,
                       Image = x.MerchImage,
                       Type = x.MerchType.MerchTypeName,
                       TypeID = x.MerchTypeId,
                       CatID = x.MerchCategoryId,
                       Category = x.MerchCategory.MerchCategoryName,
                       Price = x.Prices.OrderByDescending(o => o.Date).Select(p => p.Price1).FirstOrDefault(),
                       Status = x.MerchStatuses.MerchStatusName,
                       Quantity = 0,
                       Feedback = x.Feedbacks.Select(x => new
                       {
                           Customer = $"{x.Client.User.Name} {x.Client.User.Surname}",
                           Date = x.Date,
                           Description = x.Description
                       })
                   }).FirstOrDefault();

            return allMerch;
        }

        public object ViewSalesOrder(string userID)
        {
            Ambassador ambassador = db.Ambassadors.FirstOrDefault(x => x.UserId == userID);

            var orders = db.Orders.Where(id => id.AmbassadorId == ambassador.AmbassadorId)
                                 .Select(x => new
                                 {
                                     Id = x.OrderId,
                                     Date = x.Date,
                                     //Status = x.OrderStatus.OrderStatusName,
                                     Amount = x.OrderItems.Sum(x => x.Price * x.Quantity),
                                     Quantity = x.OrderItems.Sum(x => x.Quantity),
                                     Customer = $"{x.User.Name} {x.User.Surname}"

                                 });
            return orders;
        }

        public object SalesOrderDetails(int id)
        {
            var orderItem = db.Orders.Where(items => items.OrderId == id).Select(x => new
            {
                Id = x.OrderId,
                Date = x.Date,
                Customer = $"{x.User.Name} {x.User.Surname}",
                Email = x.User.Email,
                Payment = x.ProofOfPayment,
                Phone = x.User.PhoneNumber,
                OrderStatus = x.OrderStatusId,
                Delivery = x.DeliveryId,
                DeliveryAmount = x.Delivery.DeliveryAmount.DeliveryAmount1,
                Address = x.Address.Address1,
                PostalCode = x.Address.PostalCode,
                City = x.Address.City,
                Province = x.Address.Province,
                OrderItems = x.OrderItems.Select(x =>
                new
                {
                    Name = x.Merchandise.MerchName ?? x.Special.SpecialName,
                    Quantity = x.Quantity,
                    Price = x.Price
                })

            }).FirstOrDefault();

            return orderItem;
        }

        public bool UpdateSalesOrderStatus(UpdateOrderVM update)
        {
            //find the item by id
            Order uOrder = db.Orders.FirstOrDefault(m => m.OrderId == update.OrderId);
            uOrder.OrderStatusId = update.OrderStatusId;

            if (update.Checked == true)
            {
                Delivery delivery = db.Deliveries.FirstOrDefault(m => m.DeliveryId == update.DeliveryId);
                delivery.TrackingNumber = update.TrackingNumber;
            }

            return true;
        }

        public object SalesOrderById(int id)
        {
            var orderItem = db.Orders.Where(items => items.OrderId == id).Select(x => new
            {
                Id = x.OrderId,
                Delivery = x.DeliveryId,
                TrackingNumber = x.Delivery.TrackingNumber,
                OrderStatusId = x.OrderStatusId
            }).FirstOrDefault();

            return orderItem;
        }

        public object GetProductList(int? type, int? category)
        {
            //return productlist;

            if (type == 0) type = null;
            if (category == 0) category = null;

            var result = from x in db.Merchandises
                         where (type == null || x.MerchTypeId == type)
                         && (category == null || x.MerchCategoryId == category)
                         select new
                         {
                             ID = x.MerchandiseId,
                             Item = x.MerchName,
                             Description = x.Description,
                             MerchType = x.MerchType.MerchTypeName,
                             MerchCat = x.MerchCategory.MerchCategoryName,
                             UnitPrice = x.Prices.OrderByDescending(x => x.Date).Select(x => x.Price1).First(),
                             Status = x.MerchStatuses.MerchStatusName
                         };

            return result;

        }


        public object AmbassadorListRep(int? province, int? ranking)
        {
            try
            {
                if (province == 0) province = null;
                if (ranking == 0) ranking = null;

                var result = from x in db.Ambassadors
                             where (province == null || x.User.Addresses.Select(x => x.ProvinceId).First() == province)
                             && (ranking == null || x.AmbassadorTypeId == ranking)
                             select new
                             {
                                 Name = x.User.Name,
                                 Surname = x.User.Surname,
                                 Email = x.User.Email,
                                 Province = x.User.Addresses.Select(x => x.Province.ProvinceName).First(),
                                 Phone = x.User.PhoneNumber,
                                 Ranking = x.AmbassadorType.AmbassadorTypeName
                             };

                return result;
            }
            catch
            {
                return false;
            }
        }

        public object SalesRep(SalesRepForm salesRep)
        {
            try
            {
                if (salesRep.Category == 0) salesRep.Category = null;
                var result = (from ord in db.Orders
                             join item in db.OrderItems on ord.OrderId equals item.OrderId
                             join merch in db.Merchandises on item.MerchandiseId equals merch.MerchandiseId
                             where salesRep.Category == null || item.Merchandise.MerchCategoryId == salesRep.Category
                             && ord.Date >= salesRep.StartDate
                             && ord.Date <= salesRep.EndDate
                             group new {merch, item} by  new{mName = merch.MerchName, iPrice = item.Price } into g
                             select new
                             {
                                 Name = g.Key.mName,
                                 Price = g.Key.iPrice,
                                 Quantity = g.Sum(x => x.item.Quantity),
                                 Total = g.Sum(x => x.item.Quantity * x.item.Price)
                             }).ToList();


                return result;

            }
            catch
            {
                return false;
            }
        }

        public object TargetRep(DateTime From, DateTime To)
        {
            try
            {
               var v = db.Referrals.Where(x => x.ReferralLinkTypeId == 2).ToList();

                var Distributor = (from refs in db.ReferralCodes
                                   join amb in db.Ambassadors on refs.AmbassadorId equals amb.AmbassadorId
                                   join tar in db.Targets on amb.AmbassadorId equals tar.AmbassadorId
                                   where From >= tar.StartDate && tar.EndDate <= To
                                   select new
                                   {
                                       AmbId = amb.AmbassadorId,
                                       Name = $"{amb.User.Name} {amb.User.Surname}",
                                       RefCode = refs.ReferralCode1.Substring(0, 2),
                                       Target = tar.Target1
                                   }).ToList();

                var Line = (from od in db.Orders
                               join item in db.OrderItems on od.OrderId equals item.OrderId
                               join amd in db.Ambassadors on od.AmbassadorId equals amd.AmbassadorId
                               join refs in db.Referrals on amd.UserId equals refs.UserId
                               group new { item ,od.AmbassadorId, refs.ReferralCode.ReferralCode1 } by new { od.AmbassadorId, refs.ReferralCode.ReferralCode1 } into results
                               orderby results.Key.AmbassadorId
                               select new
                               {
                                  
                                   AmbassadorId = results.Key.AmbassadorId,
                                   RefCode = results.Key.ReferralCode1.Substring(0, 2),
                                   Sales = results.Sum(x => x.item.Quantity * x.item.Price)
                               }
                              ).ToList();

                var DistributorLine = (from d in Distributor
                                       join l in Line on d.RefCode equals l.RefCode
                                       group l by d into g
                                       select new
                                       {
                                           Distributor = g.Key.Name,
                                           Ambassador = g.Count(),
                                           Target = g.Key.Target,
                                           Sales = g.Sum(x => x.Sales),
                                           Remaining = g.Key.Target - g.Sum(x => x.Sales)

                                       }).ToList();

                return DistributorLine;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }
        }
        public object LoggedInName(string id)
        {
            var user = db.Users.Where(x => x.UserId.ToString() == id).Select(x => new { Name = $"{x.Name} ${x.Surname}" });
            return user;
        }

        public object RecruitmentRep(int month)
        {
            try
            {

                var applications = from app in db.Applications
                                   join amb in db.Ambassadors on app.UserId equals amb.UserId
                                   where app.Date.Value.Month == month
                                   group new { app, amb} by new { app.ApplicationStatusId, amb.AmbassadorType.AmbassadorTypeName } into g
                             select new
                             {
                                 Ranking = g.Key.AmbassadorTypeName,
                                 Pending = g.Count(x => x.app.ApplicationStatusId == 1),
                                 Approved = g.Count(x => x.app.ApplicationStatusId == 2),
                                 Rejected = g.Count(x => x.app.ApplicationStatusId == 3),
                                 Total = g.Count(x => x.app.ApplicationStatusId == 1 || x.app.ApplicationStatusId == 2 || x.app.ApplicationStatusId == 3)

                             };


                return applications;
            }
            catch (Exception ex)
            {
                return ex.InnerException.Message;
            }

        }
        public object TopSeller(int? province, int? ranking)
        {
            if (province == 0) province = null;
            if (ranking == 0) ranking = null;

            //var sales = (from item in db.OrderItems
            //             from ord in db.Orders 
            //             where item.OrderId == ord.OrderId
            //             group ord by ord.AmbassadorId into g
            //             select new
            //             {
            //                  Id = g.Key,
            //                  Sale =g.Sum(x=> x.)
            //             }).ToList();

            //var sales = (from ord in db.Orders
            //             join item in db.OrderItems on  ord.OrderId equals item.OrderId
            //             join amb in db.Ambassadors on ord.AmbassadorId equals amb.AmbassadorId
            //             group new { ord, item, amb } by new { ord, item, amb } into g
            //             select new
            //             {

            //                 Name = g.Key.amb.User.Name,
            //                 Surname = g.Key.amb.User.Surname,
            //                 Email = g.Key.amb.User.Email,
            //                 province = g.Key.amb.User.Addresses.Select(x => x.ProvinceId).First(),
            //                 sales = g.Sum(x => x.item.Price),
            //                 ranking = g.Key.amb.AmbassadorType.AmbassadorTypeName

            //             }).ToList();

            //var sales = db.OrderItems
            //                      .Join(db.Orders.AsEnumerable(), item => item.OrderId, ord => ord.OrderId, (item, ord) => new { item, ord })
            //                      .Join(db.Ambassadors.AsEnumerable(), Ord => Ord.ord.Cart, amb => amb.AmbassadorId, (Ord, amb) => new { Ord, amb }).AsEnumerable()
            //                      .Where(x => province == null || x.ord.Ambassador.User.Addresses.Select(x => x.ProvinceId).First() == province)
            //                      .Where(x => ranking == null || x.ord.Ambassador.AmbassadorTypeId == ranking)
            //                      .GroupBy(x => new { x.ord.Ambassador, x.ord.OrderId })
            //                      .Select(x => new
            //                      {
            //                          AmbassadorId = x.Key.OrderId,
            //                          Username = $"{x.Key.Ambassador.User.Name} {x.Key.Ambassador.User.Surname}",
            //                          SalesTotal = x.Sum(y => y.item.Price)
            //                      })
            //                      .OrderByDescending(x => x.SalesTotal)
            //                      .Select((x, index) => new 
            //                      {
            //                          AmbassadorId = x.AmbassadorId,
            //                          Username = x.Username,
            //                          SalesTotal = x.SalesTotal,
            //                          Rank = index,
            //                      }).ToList();

            //var sales = db.OrderItems
            //    .Join()
            //   .GroupBy(x => x.Order.Ambassador) // ApplicationUser
            //   .Select(x =>
            //   {
            //        AmbassadorId = x.Key.AmbassadorId,
            //        Username = x.Key.UserName,
            //        SalesTotal = x.Sum(y => y.Price)

            //   })
            //   .OrderByDescending(x => x.SalesTotal)
            //   .AsEnumerable()
            //   .Select((x, index) => new UserSale
            //   {
            //       AmbassadorId = x.UserId,
            //       Username = x.Username,
            //       SalesTotal = x.SalesTotal,
            //       Rank = index,
            //   });

            return "";

        }



        public void CheckoutEmail(string email,string sub ,string username, string message)
        {
            using (MailMessage emailSend = new MailMessage("u20551313@tuks.co.za", email))
            {
                emailSend.Subject = "Welcome to SAiCs!!!";
                emailSend.Body = message;
                emailSend.IsBodyHtml = false;
                using (SmtpClient Smtp = new SmtpClient())
                {
                    Smtp.Host = "smtp.gmail.com";
                    Smtp.EnableSsl = true;
                    NetworkCredential credentials = new NetworkCredential("u20551313@tuks.co.za", "FentseT@21");
                    Smtp.UseDefaultCredentials = false;
                    Smtp.Credentials = credentials;
                    Smtp.Port = 587;
                    Smtp.Send(emailSend);
                }
            }
        }

        public object TopProduct(SalesRepForm salesRep)
        {
            if (salesRep.Category == 0) salesRep.Category = null;
            var result = (from ord in db.Orders
                          join item in db.OrderItems on ord.OrderId equals item.OrderId
                          join merch in db.Merchandises on item.MerchandiseId equals merch.MerchandiseId
                          where salesRep.Category == null || item.Merchandise.MerchCategoryId == salesRep.Category
                          && ord.Date >= salesRep.StartDate
                          && ord.Date <= salesRep.EndDate
                          group new { merch, item } by new { mName = merch.MerchName, iPrice = item.Price } into g
                          select new
                          {
                              Name = g.Key.mName,
                              Quantity = g.Sum(x => x.item.Quantity)
                          }).OrderByDescending(x => x.Quantity).Take(10);


            return result;
        
        }

        /// <summary>
        ////////////////////////////////// AMANDA CODE /////////////////////////////
        /// </summary>
        public object FindRefferalLink(string refferalCode)
        {
            var refferalrecord = db.ReferralCodes.Where(refferalcode => refferalcode.ReferralCode1 == refferalCode).FirstOrDefault();

            if (refferalrecord != null)
            {
                var linkedUserDetails = db.Ambassadors.Where(linkedambassador => linkedambassador.AmbassadorId == refferalrecord.AmbassadorId).Select(id => id.AmbassadorId).ToList();
                return linkedUserDetails[0];
                //Accidently did code for find ambassador refferals/clients and ambassador etc
                //var userlinked = db.Referrals.Where(refferalID => refferalID.ReferralCodeId == refferalrecord.ReferralCodeId).FirstOrDefault();
                //var userrefferalcode = db.ReferralCodes.Where(code => code.ReferralCodeId == userlinked.ReferralCodeId).FirstOrDefault();
                //var ambdetails = db.Ambassadors.Where(ambrefferaldetails => ambrefferaldetails.AmbassadorId == userrefferalcode.AmbassadorId).FirstOrDefault();
                ////var ambdetails = db.Ambassadors.Where(amb => amb.UserId == userlinked.UserId).FirstOrDefault();
                //return ambdetails;
            }
            else
            {
                return "Couldnt find user";
            }

        }

        private bool LinkUsers(string refferalCode, string emailaddress, string usertype)
        {
            var refferalrecord = db.ReferralCodes.Where(refferalcode => refferalcode.ReferralCode1 == refferalCode).FirstOrDefault();
            try
            {
                if (usertype == "Client")
                {

                    Referral linking = new Referral();
                    linking.ReferralCodeId = refferalrecord.ReferralCodeId;
                    linking.ReferralLinkTypeId = 1;
                    linking.Date = DateTime.Now;
                    var userId = db.Users.Where(email => email.Email == emailaddress).Select(userid => userid.Id).ToList();
                    linking.UserId = userId[0];
                    Add(linking);
                    SaveChanges();
                    return true;
                }
                if (usertype == "Ambassador")
                {
                    Referral linking = new Referral();
                    linking.ReferralCodeId = refferalrecord.ReferralCodeId;
                    linking.ReferralLinkTypeId = 2;
                    linking.Date = DateTime.Now;
                    var userId = db.Users.Where(email => email.Email == emailaddress).Select(userid => userid.Id).ToList();
                    linking.UserId = userId[0];
                    Add(linking);
                    SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception error)
            {
                return false;
            }


        }

        public object Find<T>(T entity) where T : class
        {
            return "";

        }

        public object GenerateRefferralCode(string name, string surname, string usedRefferralCode)
        {
            string distributor = usedRefferralCode.Substring(0, 5);
            Random rndNum = new Random();
            int[] code = new int[4];
            for (int j = 0; j < 4; j++)
            {
                code[j] = (rndNum.Next(0, 10));
            }
            var refferralcode = distributor + name.Substring(0, 2).ToUpper() + surname.Substring(0, 2).ToUpper() + string.Join("", code);
            return refferralcode;

        }
        public object GenerateToken(User user)
        {
            //User userLogin = user;
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(JwtRegisteredClaimNames.UniqueName, user.UserName),
                new Claim(ClaimTypes.Role, user.UserRole.UserRoleName),
                new Claim("UserID", user.Id)

            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Tokens:Key"]));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

            var token = new JwtSecurityToken(
                _configuration["Tokens:Issuer"],
                _configuration["Tokens:Audience"],
                claims,
                signingCredentials: credentials,
                expires: DateTime.UtcNow.AddHours(5)
           );

            return new
            {
                token = new JwtSecurityTokenHandler().WriteToken(token),
                expiration = token.ValidTo

            };
        }


        public bool CheckPassword(string id, string password)
        {
            var passwordRecord = db.Passwords.Where(userid => userid.UserId == id).ToList();
            if (BCrypt.Net.BCrypt.Verify(password, passwordRecord[0].Password1) == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public object ViewCurrentAgents(string userID)
        {
            var ambassadorRecord = db.Ambassadors.Where(user => user.UserId == userID).ToList();
            var refferalId = db.ReferralCodes.Where(ambassadorID => ambassadorID.AmbassadorId == ambassadorRecord[0].AmbassadorId).ToList();
            var agentsLinked = db.Referrals.Where(ambID => ambID.ReferralCodeId == refferalId[0].ReferralCodeId && ambID.ReferralLinkTypeId == 2)
                                                                        .Include(user => user.User)
                                                                        .ThenInclude(t => t.Title)
                                                                        .Include(user => user.User)
                                                                        .ThenInclude(type => type.Ambassadors)
                                                                        .ThenInclude(type => type.AmbassadorType)
                                                                        .ToList();

            return agentsLinked;
            // throw new NotImplementedException();
        }

        public object ViewCurrentClients(string userID)
        {
            var ambassadorRecord = db.Ambassadors.Where(user => user.UserId == userID).ToList();
            var refferalId = db.ReferralCodes.Where(ambassadorID => ambassadorID.AmbassadorId == ambassadorRecord[0].AmbassadorId).ToList();
            var clientsLinked = db.Referrals.Where(ambID => ambID.ReferralCodeId == refferalId[0].ReferralCodeId && ambID.ReferralLinkTypeId == 1)
                                                                        .Include(user => user.User)
                                                                        .ThenInclude(t => t.Title)
                                                                        .Include(user => user.User)
                                                                        .ThenInclude(type => type.Ambassadors)
                                                                        .ThenInclude(type => type.AmbassadorType)
                                                                        .ToList();

            return clientsLinked;
            // throw new NotImplementedException();
        }

        public object SearchCurrentAgents(string userID, string searchInput)
        {
            var ambassadorRecord = db.Ambassadors.Where(user => user.UserId == userID).ToList();
            var refferalId = db.ReferralCodes.Where(ambassadorID => ambassadorID.AmbassadorId == ambassadorRecord[0].AmbassadorId).ToList();
            var searchedagentsLinked = db.Referrals.Where(ambID => ambID.ReferralCodeId == refferalId[0].ReferralCodeId && ambID.ReferralLinkTypeId == 2)
                                                                        .Include(user => user.User)
                                                                        .ThenInclude(type => type.Ambassadors)
                                                                        .ThenInclude(type => type.AmbassadorType)
                                                                        .Include(user => user.User).Where(searchInfo => searchInfo.User.Name.Contains(searchInput) || searchInfo.User.Surname.Contains(searchInput))
                                                                        .ToList();
            if (searchedagentsLinked.Count() == 0)
            {
                return "Not Found";
            }
            return searchedagentsLinked;

        }

        public bool RequestRankingPromotion(string userID)
        {
            try
            {
                var ambassadorRecord = db.Ambassadors.Where(id => id.UserId == userID).ToList();
                PositionRequest newPositionRequest = new PositionRequest { AmbassadorId = ambassadorRecord[0].AmbassadorId, RequestTypeId = 1, Date = DateTime.Now };
                Add(newPositionRequest);
                SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool RequestRankingDemotion(string userID)
        {
            try
            {
                var ambassadorRecord = db.Ambassadors.Where(id => id.UserId == userID).ToList();
                PositionRequest newPositionRequest = new PositionRequest { AmbassadorId = ambassadorRecord[0].AmbassadorId, RequestTypeId = 2, Date = DateTime.Now };
                Add(newPositionRequest);
                SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public object ViewClient(string userID)
        {
            var ambassadorRecord = db.Ambassadors.Where(user => user.UserId == userID).ToList();
            var refferalId = db.ReferralCodes.Where(ambassadorID => ambassadorID.AmbassadorId == ambassadorRecord[0].AmbassadorId).ToList();
            var agentsLinked = db.Referrals.Where(ambID => ambID.ReferralCodeId == refferalId[0].ReferralCodeId && ambID.ReferralLinkTypeId == 1).Include(user => user.User).ThenInclude(amb => amb.Ambassadors).ToList();
            return agentsLinked;

        }

        public object ViewAmbassadorFeedback(string userID)
        {
            var ambassadorRecord = db.Ambassadors.Where(user => user.UserId == userID).ToList();
            //note feedbacktype 1 is products and feedbacktype 2 is ambassador
            var feedbacks = db.Feedbacks.Where(ambid => ambid.AmbassadorId == ambassadorRecord[0].AmbassadorId && ambid.FeedbackTypeId == 2).ToList();
            return feedbacks;
        }

        public object SearchAmbassador(string name, string surname)
        {
            var searchedAmbassador = db.Users.Where(search => search.Name == name || search.Surname == surname).ToList();
            var searchResult = db.Ambassadors.Where(user => user.UserId == searchedAmbassador[0].Id).Include(userinfo => userinfo.User).ToList();

            if (searchResult.Count() > 1)
            {
                return searchResult[0];
            }
            else
            {
                return null;
            }

        }


        public object AssignCourse(int userID)
        {
            var Ambassador = db.Users.Where(u => u.UserId == userID).Include(a => a.Addresses)
                                                                    .Include(Amb => Amb.Ambassadors)
                                                                    .ThenInclude(AmbType => AmbType.AmbassadorType)
                                                                    .ToList();

            return Ambassador;
        }

        public object UpdateUser(ProfileVM user)
        {
            //find user
            var existingUser = db.Users.Where(id => id.Id == user.Id).Include(address => address.Addresses)
                                                                          .ThenInclude(country => country.Country)
                                                                          .Include(title => title.Title)
                                                                          .Include(userrole => userrole.UserRole)
                                                                          .Include(refferral => refferral.Referrals)
                                                                          .ThenInclude(code => code.ReferralCode)
                                                                          .Include(address => address.Addresses)
                                                                          .ThenInclude(province => province.Province)
                                                                          .FirstOrDefault();

            //update user
            existingUser.TitleId = user.TitleId;
            existingUser.Name = user.Name;
            existingUser.Surname = user.Surname;
            //existingUser.Email = user.Email;
            existingUser.PhoneNumber = user.PhoneNumber;

            //update address
            var existingAddress = db.Addresses.Where(id => id.UserId == user.Id)
                                                        .Include(province => province.Province)
                                                        .Include(country => country.Country)
                                                        .FirstOrDefault();
            existingAddress.CountryId = user.CountryId;
            existingAddress.Address1 = user.Address;
            existingAddress.PostalCode = user.PostalCode;
            existingAddress.City = user.City;
            existingAddress.ProvinceId = user.ProvinceId;


            return true;
        }

        public object PositionRequests()
        {
            List<PositionRequestsVM> allPositionRequests = new List<PositionRequestsVM>();


            //get all postionRequests 
            var requests = db.PositionRequests.Include(position => position.RequestType).Include(amb => amb.Ambassador).ThenInclude(rank => rank.AmbassadorType).ToList();

            for (var i = 0; i < requests.Count(); i++)
            {
                //variable for storing everything in Position request view model
                Ambassador ambassadorsPositionRequests = new Ambassador();
                List<Order> ambassadorsOrders = new List<Order>();

                //finding the ambassador who wants a position request
                var foundAmb = db.Ambassadors.Where(ambid => ambid.AmbassadorId == requests[i].AmbassadorId).FirstOrDefault();
                var foundUser = db.Users.Where(id => id.Id == foundAmb.UserId).FirstOrDefault();

                //add user(Ambassador to list)
                Ambassador positionUser = new Ambassador();
                positionUser = foundAmb;
                //positionUser.Name = foundUser.Name;
                //positionUser.Surname = foundUser.Surname;
                //positionUser.Email = foundUser.Email;
                //positionUser.PhoneNumber = foundUser.PhoneNumber;
                ambassadorsPositionRequests = positionUser;

                //find all the orders linked to ambassador
                //var orders = db.Orders.Where(ambid => ambid.AmbassadorId == requests[i].AmbassadorId).ToList();

                //for (var x = 0; x<= orders.Count(); x++)
                //{
                //    Order positionUserOrders = new Order();
                //    positionUserOrders = orders[x];
                //    //positionUserOrders.Address = orders[x].Address;
                //    ambassadorsOrders.Add(positionUserOrders);

                //}
                PositionRequestsVM appendPositionRequest = new PositionRequestsVM();
                appendPositionRequest.Ambassador = ambassadorsPositionRequests;
                //appendPositionRequest.Orders = ambassadorsOrders;
                allPositionRequests.Add(appendPositionRequest);
                //add order of teh user(ambassador) to list
                //Order positionUsersOrders =
                //ambassadorsOrders.Add((Order)db.Orders.Where(ambid => ambid.AmbassadorId == requests[i].AmbassadorId));
            }

            //PositionRequestsVM positionrequests = new PositionRequestsVM();
            //positionrequests.Ambassadors = ambassadorsPositionRequests;
            //positionrequests.Orders = ambassadorsOrders;
            return allPositionRequests;

            //for (var i = 0; i<= requests.Count();i++)
            //{
            //    var ambRefferral = db.ReferralCodes.Where(amb => amb.AmbassadorId == requests[i].AmbassadorId).FirstOrDefault();
            //     this.FindRefferalLink(ambRefferral.ReferralCode1);
            //   // db.Referrals.Where(ambid => ambid.re)
            //}



        }

        public void deleteFAQ(int faqId)
        {
            var deleteFAQ = db.Faqs.Where(faq => faq.Faqid == faqId).FirstOrDefault();
            Delete(deleteFAQ);
        }

        public void deleteFAQCategory(int faqCategoryId)
        {
            var deleteFAQCategory = db.Faqcategories.Where(category => category.FaqcategoryId == faqCategoryId).FirstOrDefault();
            Delete(deleteFAQCategory);

        }

        public string GenerateOTP()
        {

            Random rndNum = new Random();
            int[] otpNum = new int[4];
            for (int j = 0; j < 4; j++)
            {
                otpNum[j] = (rndNum.Next(0, 10));
            }
            return string.Join("", otpNum);

        }

        public bool VerifyOTP(string userID, string otp)
        {
            var verifyOTP = db.Passwords.Where(id => id.UserId == userID).FirstOrDefault();
            if (BCrypt.Net.BCrypt.Verify(otp, verifyOTP.HashedOtp) == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool deleteAmbassador(string userid)
        {
            try
            {
                //delete user info
                var deleteUserInfo = db.Users.Where(id => id.Id == userid)
                    .Include(ambassador => ambassador.Ambassadors)
                    .ThenInclude(rcode => rcode.ReferralCodes)
                    .FirstOrDefault();
                var DeleteUserApplication = db.Applications.Where(id => id.UserId == userid).FirstOrDefault();

                //find who he/she is linked to (up line)
                var linkedPersonInfo = db.Referrals.Where(id => id.UserId == userid).FirstOrDefault();

                //find linked persons(up line) refferral code
                var replacementRefferralCode = db.ReferralCodes
                    .Where(code => code.ReferralCodeId == linkedPersonInfo.ReferralCodeId)
                    .FirstOrDefault();

                //delete user ambassadors info
                var dUserAmbassadorInfo = db.Ambassadors.Where(user => user.UserId == deleteUserInfo.Id).FirstOrDefault();
                var dUserAmbassadorInfoRefferralCode = db.ReferralCodes.Where(usercode => usercode.AmbassadorId == dUserAmbassadorInfo.AmbassadorId).FirstOrDefault();

                //replace the users linked
                var replaceUserLinkings = db.Referrals
                    .Where(link => link.ReferralCodeId == dUserAmbassadorInfoRefferralCode.ReferralCodeId)
                    .ToList();

                for (var d = 0; d <= replaceUserLinkings.Count() - 1; d++)
                {
                    replaceUserLinkings[d].ReferralCodeId = replacementRefferralCode.ReferralCodeId;
                }

                var addresses = db.Addresses.Where(id => id.UserId == userid).ToList();
                if (addresses.Count() > 1)
                {
                    for (int i = 0; i <= addresses.Count(); i++)
                    {
                        Delete(addresses[i]);
                    }
                }
                else
                {
                    Delete(addresses[0]);
                }
                Delete(DeleteUserApplication);
                Delete(linkedPersonInfo);
                Delete(deleteUserInfo);
                return true;
            }
            catch
            {
                return false;
            }

        }
        public bool deleteClient(string userid)
        {
            try
            {
                var userDelete = db.Users.Where(id => id.Id == userid).FirstOrDefault();
                var DeleteUserApplication = db.Applications.Where(id => id.UserId == userid).FirstOrDefault();
                var refferralDelete = db.Referrals.Where(user => user.UserId == userid).FirstOrDefault();

                var addresses = db.Addresses.Where(id => id.UserId == userid).ToList();
                if (addresses.Count() > 1)
                {
                    for (int i = 0; i <= addresses.Count(); i++)
                    {
                        Delete(addresses[i]);
                    }
                }
                else
                {
                    Delete(addresses[0]);
                }
                Delete(DeleteUserApplication);
                Delete(refferralDelete);
                Delete(userDelete);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool ReplaceRefferralCodes(string userid)
        {

            //delete user ambassadors info
            var dUserAmbassadorInfo = db.Ambassadors.Where(user => user.UserId == userid).FirstOrDefault();
            var dUserAmbassadorInfoRefferralCode = db.ReferralCodes.Where(usercode => usercode.AmbassadorId == dUserAmbassadorInfo.AmbassadorId).FirstOrDefault();

            //find who he/she is linked to (up line)
            var linkedPersonInfo = db.Referrals.Where(id => id.UserId == userid).FirstOrDefault();
            var linkedPersonAmbId = db.ReferralCodes.Where(codeid => codeid.ReferralCodeId == linkedPersonInfo.ReferralCodeId).FirstOrDefault();
            var replaceUserLinkings = db.Referrals
                    .Where(link => link.ReferralCodeId == dUserAmbassadorInfoRefferralCode.ReferralCodeId)
                    .ToList();


            var replaceUserClientsLinks = db.Clients.Where(amb => amb.AmbassadorId == dUserAmbassadorInfo.AmbassadorId).ToList();
            //replace their refferral codes
            for (var d = 0; d <= replaceUserLinkings.Count() - 1; d++)
            {
                replaceUserLinkings[d].ReferralCodeId = linkedPersonInfo.ReferralCodeId;
            }

            for (var replace = 0; replace <= replaceUserClientsLinks.Count() - 1; replace++)
            {
                replaceUserClientsLinks[replace].AmbassadorId = linkedPersonAmbId.AmbassadorId;
            }



            return true;
        }

    }


}

