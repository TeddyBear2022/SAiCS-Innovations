﻿using SAiCSInnovationsAPI_3._0.Models;
using SAiCSInnovationsAPI_3._0.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace SAiCSInnovationsAPI_3._0.Repository
{
    public interface ISAiCSInnovationsRep
    {
        //Teddys interface repository code
        void Add<T>(T entity) where T : class;
        void Delete<T>(T entity) where T : class;
        object Find<T>(T entity) where T : class;
        void DontModify<T>(T entity) where T : class;
        public bool SaveChanges();
        abstract object FindFAQ(int entityid);
        abstract object getAllFAQs();
        void Emails(string email, string username, string password, int usertype);
       // bool RegisterUser(RegisterVM registration);
        object GetAllAdmins();
        object GetAllAmbassadors();
        object GetAllClients();
        //bool Login(LoginVM logindetails);
        object getUserSessionInfo(LoginVM logindetails);
        object GetTitles();
        object GetCountry();
        object GetUserRoles();
        object GetAmbassadorTypes();
        object FindFeedback(int id);
        //object GetProductFeedbacks();
        //object GetAmbassadorFeedbacks();
        //object GetAccountFAQs();
        //object GetProductFAQs();
        //object GetDeliveryFAQs();
        object MyAmbassador(int id);
        //object GetCatalogByCategory(int id);
        object GetFAQCategories();
        //bool RegisterClient(RegisterVM registration);
        bool updateFAQ(Faq faq);
        void deleteFAQ(int faqId);
        //Iteration 06
        object FindRefferalLink(string refferalCode);
        object ViewCurrentAgents(string userID);
        object ViewClient(string userID);
        bool RequestRankingPromotion(string userID);
        bool RequestRankingDemotion(string userID);
        object ViewAmbassadorFeedback(string userID);
        object SearchAmbassador(string name, string surname);


        object GenerateRefferralCode(string name, string surname, string usedRefferralCode);
        object GenerateToken(User user);
        bool CheckPassword(string userid, string password);

        //Amandas interface repository code
        //Amanda changes
        object GetSecondaryAddress(string id);
        object GetSecondaryAddressById(int id);
        object AddSecondaryAddress(Address address);
        object EditSecondaryAddress(Address address);
        object DeleteSecondaryAddress(int id);
        object ViewCatalog();
        object ViewCatalogItem(int id);

        object CreateMerch(MerchVM merch);
        object UpdateMerch(int id, MerchVM merch);
        object DeleteMerch(int id);
        object GetAllMerch();
        object GetMerchById(int id);
        object AmbassadorDiscount(string id);
        object GetVAT();
        object UpdateVAT(int id, decimal amount);

        //SPECIALS
        object GetSpecialOptions();
        object GetSpecialTypes();
        object GetAllSpecials();
        object GetSpecialById(int id);
        object addSpecial(SpecialVM vm);
        object UpdateSpecial(SpecialVM vm);
        object DeleteSpecial(int id);

        //Client Subsystem
        object GetAssociatedAmbassador(string userId); // Will be put in user
        object PurchasedProducts(string userId);
        bool AddFeedback(string userId, Feedback feedback);
        object GetProductFeedbacks(string userId);
        object GetAmbassadorFeedbacks(string id);
        bool DeleteFeedback(int id);
        object ViewClientFAQ(string userId);



        //Amanda Iteration 6
        //Generic function
        T FindById<T>(int id) where T : class;
        IEnumerable<T> Search<T>(Expression<Func<T, bool>> predicate) where T : class;
        List<T> GetAll<T>() where T : class;

        //Cart functions
        object AddToCart(string id, CartItem cartitem);
        object RemoveFromCart(int itemID);
        object ClearCart(int cartID);
        object Checkout(Order checkout);
        object loadCart(string id);
        object increaseCartItem(int id);
        object decreaseCartItem(int id);
        object ViewOrderHistory(string userID);
        object ViewOrderDetails(int orderID);
        object AgentAccountInfo(string id);

        //Ambassador Subsystem
        object ViewSalesOrder(string userID);
        object SalesOrderDetails(int id);
        object SalesOrderById(int id);
        bool UpdateSalesOrderStatus(UpdateOrderVM update);

        //Report
        object GetProductList(int? type, int? category);
        object AmbassadorListRep(int? province, int? ranking);
        object SalesRep(SalesRepForm salesRep);
        object RecruitmentRep(int month);
        object TargetRep(DateTime From, DateTime To);
        object TopSeller(int? province, int? ranking);
        object TopProduct(SalesRepForm salesRep);
        object LoggedInName(string id);

        //REVAMP SEASON
        bool ValidateRefferralCode(string refferalCode);
        object ApplicationStatus(string id);
        object UpdateUser(ProfileVM user);
        object PositionRequests();
        void deleteFAQCategory(int faqCategoryId);
        string GenerateOTP();
        bool VerifyOTP(string userID, string otp);
        object SearchCurrentAgents(string userID, string searchInput);
        bool deleteAmbassador(string userid);
        bool deleteClient(string userid);
        bool ReplaceRefferralCodes(string userid);
        void UserAmbRegister(RegisterVM registration);
        bool UserExists(string email);
        void GenerateAmbassadorsRefferral(RegisterVM registration, int ambassadorID);
        void RegisterUser(RegisterVM registration);
        void LinkUsers(string refferalCode, string emailaddress, int usertype);
        Ambassador FindAmbassador(string email);
        string ytVideo(string link);
        object ViewCurrentClients(string userID);


    }
}
