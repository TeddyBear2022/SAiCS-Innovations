﻿using SAiCSInnovationsAPI_3._0.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAiCSInnovationsAPI_3._0.ViewModels
{
    public class RegisterVM
    {
        public AccessinfoVM AccessInfo { get; set; }
        public RegistrationInfoVM RegisterInfo { get; set; }
        public BankAccount bankAccount { get; set; }
    }
}
