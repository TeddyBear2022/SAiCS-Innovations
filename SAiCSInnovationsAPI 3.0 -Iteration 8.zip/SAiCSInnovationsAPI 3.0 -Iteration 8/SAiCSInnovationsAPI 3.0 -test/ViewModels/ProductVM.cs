﻿//using SAiCSInnovationsAPI_3._0.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAiCSInnovationsAPI_3._0.ViewModels
{
    public class ProductVM
    {

        //public Product product { get; set; }
        //public ProductType productType { get; set; }
        //public ProductPrice productPrice { get; set; }
        //public Price price { get; set; }
    }
}
