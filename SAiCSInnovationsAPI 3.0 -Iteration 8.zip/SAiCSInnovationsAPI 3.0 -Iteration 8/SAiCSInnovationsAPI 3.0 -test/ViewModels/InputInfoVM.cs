﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAiCSInnovationsAPI_3._0.ViewModels
{
    public class InputInfoVM
    {
        public object Provinces { get; set; }
        public object Countries { get; set; }
        public object Titles { get; set; }
        public object UserTypes { get; set; }
        public object AmbassadorTypes { get; set; }
    }
}
