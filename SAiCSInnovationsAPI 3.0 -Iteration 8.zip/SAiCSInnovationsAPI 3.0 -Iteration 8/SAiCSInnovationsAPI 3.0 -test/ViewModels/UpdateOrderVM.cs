﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAiCSInnovationsAPI_3._0.ViewModels
{
    public class UpdateOrderVM
    {
        public int OrderId { get; set; }
        public bool Checked { get; set; }
        public int DeliveryId { get; set; }
        public int OrderStatusId { get; set; }
        public string TrackingNumber { get; set; }

    }
}
