﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAiCSInnovationsAPI_3._0.ViewModels
{
    public class AccessinfoVM
    {
        public string Username { get; set; }
        public string Password { get; set; }

    }
}
