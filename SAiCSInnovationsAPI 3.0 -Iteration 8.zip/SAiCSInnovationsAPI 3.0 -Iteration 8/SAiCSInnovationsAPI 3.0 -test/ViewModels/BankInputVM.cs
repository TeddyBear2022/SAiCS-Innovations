﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAiCSInnovationsAPI_3._0.ViewModels
{
    public class BankInputVM
    {
        public object BankNames { get; set; }
        public object AccountTypesNames { get; set; }
    }
}
