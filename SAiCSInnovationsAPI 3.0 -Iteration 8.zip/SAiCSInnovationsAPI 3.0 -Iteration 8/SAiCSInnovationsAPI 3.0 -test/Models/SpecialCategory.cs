﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAiCSInnovationsAPI_3._0.Models
{
    public partial class SpecialCategory
    {
        public SpecialCategory()
        {
            MerchSpecials = new HashSet<MerchSpecial>();
        }

        public int SpecialCategoryId { get; set; }
        public string SpecialCategoryName { get; set; }

        public virtual ICollection<MerchSpecial> MerchSpecials { get; set; }
    }
}
