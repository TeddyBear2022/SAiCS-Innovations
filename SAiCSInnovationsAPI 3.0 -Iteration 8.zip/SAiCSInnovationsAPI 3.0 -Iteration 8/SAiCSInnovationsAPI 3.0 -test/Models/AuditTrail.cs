﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SAiCSInnovationsAPI_3._0.Models
{
    public partial class AuditTrail
    {
       
        public int AuditTrailId { get; set; }
        public string UserId { get; set; }
        public string Username { get; set; }
        public string TransactionType { get; set; }
        public string TableName { get; set; }
        public DateTime DateTime { get; set; }
        public string OldValues { get; set; }
        public string NewValues { get; set; }
        public string AffectedColumns { get; set; }
        public string PrimaryKey { get; set; }
        public virtual User User { get; set; }
    }
}
