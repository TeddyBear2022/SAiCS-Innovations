﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using SAiCSInnovationsAPI_3._0.Models;
using SAiCSInnovationsAPI_3._0.Repository;
using SAiCSInnovationsAPI_3._0.ViewModels;
using SendGrid;
using SendGrid.Helpers.Mail;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace SAiCSInnovationsAPI_3._0.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class ClientOrderController : ControllerBase
    {
        private readonly ISAiCSInnovationsRep _rep;
        public ClientOrderController(ISAiCSInnovationsRep rep)
        {
            _rep = rep;
        }

        [HttpGet("ViewOrderDetails")]
        public object ViewOrderDetails(int id)
        {
            try
            {
                return _rep.ViewOrderDetails(id);
            }
            catch
            {
                return false;
            }
        }



        [HttpPost("AddToCart")]
        public object AddToCart(string id, CartItem cartitem)
        {
            try
            {
                var userid = this.User.FindFirst("UserID").Value;
                return _rep.AddToCart(this.User.FindFirst("UserID").Value, cartitem);
            }
            catch
            {
                return false;
            }
        }

        [HttpDelete("RemoveFromCart")]
        public object RemoveFromCart(int itemID)
        {
            try
            {
                return _rep.RemoveFromCart(itemID);
            }
            catch
            {
                return false;
            }

        }

        [HttpDelete("ClearCart")]
        public object ClearCart(int cartID)
        {
            try
            {
                return _rep.ClearCart(cartID);
            }
            catch
            {
                return false;
            }

        }

        [HttpGet("ViewCart")]
        public object ViewCart(string id)
        {
            try
            {
                return _rep.loadCart(this.User.FindFirst("UserID").Value);
            }
            catch
            {
                return false;
            }

        }

        [HttpPost("IncreaseCartItem")]
        public object IncreaseCartItem(int id)
        {
            try
            {
                return _rep.increaseCartItem(id);
            }
            catch
            {
                return false;
            }

        }

        [HttpPost("DecreaseCartItem")]
        public object DecreaseCartItem(int id)
        {
            try
            {
                return _rep.decreaseCartItem(id);
            }
            catch
            {
                return false;
            }

        }

        [HttpPost("Checkout")]
        public object Checkout(Order checkout)
        {
            try
            {
                return _rep.Checkout(checkout);
            }
            catch
            {
                return false;
            }
        }

        [HttpGet("ViewOrderHistory")]
        public object ViewOrderHistory(string userID)
        {
            try
            {
                return _rep.ViewOrderHistory(userID);
            }
            catch
            {
                return false;
            }
        }

        [HttpPost("Email")]
        public async Task<ActionResult> Email(string emailto, string name, string surname, string username, string password)
        {
            var apiKey = "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";
            var client = new SendGridClient(apiKey);
            var from = new EmailAddress("saicsinnovations@gmail.com", "Saics Innovations");
            var subject = "Order Received";
            var to = new EmailAddress(emailto);
            var plainTextContent = "and easy to do anywhere, even with C#";
            var htmlContent = "Thanks For Shopping With SAICS!Your order Will be processed soon!";
            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            var response = await client.SendEmailAsync(msg);
            return Ok(true);
        }
        [HttpPost("ResetPasswordEmail")]
        public async Task<ActionResult> ResetPasswordEmail(string emailto, string name, string surname, string username, string password)
        {
            var apiKey = "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";
            var client = new SendGridClient(apiKey);
            var from = new EmailAddress("saicsinnovations@gmail.com", "Saics Innovations");
            var subject = "Password Reset";
            var to = new EmailAddress(emailto);
            var plainTextContent = "and easy to do anywhere, even with C#";
            var htmlContent = $"<h2><b>Greetings {name + ' ' + surname}!</b></h2><br> Your password has been reset at {DateTime.UtcNow} <br> Your new Login credentials are as follows:<br>" +
                $"Username: {username} <br>" +
                $"Password: {password}";
            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            var response = await client.SendEmailAsync(msg);
            return Ok(true);
        }

    }
}
