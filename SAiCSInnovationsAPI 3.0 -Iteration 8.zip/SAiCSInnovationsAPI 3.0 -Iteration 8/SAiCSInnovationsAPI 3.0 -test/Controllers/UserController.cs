﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using SAiCSInnovationsAPI_3._0.Models;
using SAiCSInnovationsAPI_3._0.Repository;
using SAiCSInnovationsAPI_3._0.ViewModels;
using SendGrid;
using SendGrid.Helpers.Mail;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace SAiCSInnovationsAPI_3._0.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly ISAiCSInnovationsRep _rep;
        private readonly SaicsInnovationsDBContext _db;
        private readonly UserManager<User> _manager;
        private readonly IUserClaimsPrincipalFactory<User> _claims;
        private readonly IConfiguration _configuration;
        // public int otp = 0;

        public UserController(UserManager<User> manager,
            IUserClaimsPrincipalFactory<User> claims,
            IConfiguration configuration,
            ISAiCSInnovationsRep rep,
             SaicsInnovationsDBContext db
            )
        {
            _manager = manager;
            _claims = claims;
            _configuration = configuration;
            _rep = rep;
            _db = db;

        }

        [HttpGet("InputInformation")]
        public ActionResult InputInformation()
        {
            try
            {
                InputInfoVM inputs = new InputInfoVM();
                var titles = _db.Titles.ToList();
                var userTypes = _db.UserRoles.ToList();
                var provinceNames = _db.Provinces.ToList();
                var countryNames = _db.Countries.ToList();
                var ambTypes = _db.AmbassadorTypes.ToList();

                inputs.Titles = titles;
                inputs.UserTypes = userTypes;
                inputs.Provinces = provinceNames;
                inputs.Countries = countryNames;
                inputs.AmbassadorTypes = ambTypes;

                return Ok(inputs);

            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }

        }


        [HttpPost("RegisterUser")]
        public async Task<ActionResult> RegisterUser(RegisterVM registration)
        {
            try
            {
                _rep.RegisterUser(registration);
                if (_rep.UserExists(registration.RegisterInfo.EmailAddress))
                {
                    return NotFound("user exists");
                }
                else
                {
                    _rep.SaveChanges();

                    _rep.LinkUsers(registration.RegisterInfo.referralcode, registration.RegisterInfo.EmailAddress, registration.RegisterInfo.UsertypeID);
                    if (registration.RegisterInfo.UsertypeID == 2)
                    {
                        var amb = _rep.FindAmbassador(registration.RegisterInfo.EmailAddress);
                        _rep.GenerateAmbassadorsRefferral(registration, amb.AmbassadorId);
                    }
                    _rep.SaveChanges();
                    await this.Email(registration.RegisterInfo.EmailAddress, registration.RegisterInfo.Name, registration.RegisterInfo.Surname, registration.AccessInfo.Username, registration.AccessInfo.Password);
                    //Registered
                    return Ok(true);
                }




                //if (registered == true)
                //{
                //    await this.Email(registration.RegisterInfo.EmailAddress, registration.RegisterInfo.Name, registration.RegisterInfo.Surname, registration.AccessInfo.Username, registration.AccessInfo.Password);
                //    //Registered
                //    return Ok(true);
                //}
                //else
                //{
                //    //Not registered
                //    return StatusCode(StatusCodes.Status500InternalServerError, "Internal error occured. Please contact support");
                //}
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }


        //Validate Refferral Code
        [HttpGet("ValidateRefferralCode")]
        public ActionResult ValidateRefferralCode(string refferalCode)
        {
            if (_rep.ValidateRefferralCode(refferalCode))
            {
                return Ok(true);
                //return true;
            }
            else
            {
                return NotFound("Refferral code invalid, not found");
            }
        }

        [HttpGet("UserExist")]
        public async  Task<ActionResult> DoesTheUserExist(string email)
        {
            try
            {
                var user = await _manager.FindByNameAsync(email);
                if (user == null)
                {
                    return Ok(false);
                }
                else
                {
                    return Ok(true);
                }
            }
            catch(Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }

        }

        //Get Admins
        [HttpGet("GetAllAdmins")]
        public object GetAllAdmins()
        {
            try
            {
                return _rep.GetAllAdmins();
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        //Get Ambassadors
        [HttpGet("GetAllAmbassadors")]
        public object GetAllAmbassadors()
        {
            return _rep.GetAllAmbassadors();
        }

        //Get Clients
        [HttpGet("GetAllClients")]
        public object GetAllClients()
        {
            try
            {
                return _rep.GetAllClients();
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpPost("Login")]
        public async Task<ActionResult> Login(LoginVM userVM)
        {
            //find user
            var user = await _manager.FindByNameAsync(userVM.EmailorUsername);
           
            if (user != null )
            {
                //validate password
                var checkpassword = _rep.CheckPassword(user.Id, userVM.Password);
                if (checkpassword == true)
                {
                    try
                    {
                        var principal = await _claims.CreateAsync(user);
                        await HttpContext.SignInAsync(IdentityConstants.ApplicationScheme, principal);
                        var infoForToken = _db.Users.Where(find => find.Id == user.Id).Include(role =>role.UserRole).FirstOrDefault();
                        _db.SaveChanges();
                        var token = _rep.GenerateToken(infoForToken);
                        return Ok(token);
                    }
                    catch (Exception error)
                    {
                        return BadRequest(error.InnerException.Message);
                    }
                }
                else
                {
                    return NotFound("wrong password or email address");
                }
                
            }
            else
            {
                return NotFound("wrong password or email address");
            }

        }

        [HttpGet("Logout")]
        public async Task<IActionResult> Logout()
        {
            try { 
            await HttpContext.SignOutAsync(IdentityConstants.ApplicationScheme);

            return Ok(true);
            }
            catch(Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, error.InnerException.Message);
            }
        }

        //Fix up
        //Delete user/profile
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpDelete("DeleteUser")]
        public async Task<ActionResult> DeleteUser()
        {
            try
            {
                var deleteUser = _db.Users.Where(id => id.Id == this.User.FindFirst("UserID").Value).Include(role => role.UserRole).FirstOrDefault();
                if (deleteUser.UserRole.UserRoleId == 1) {
                    
                    _rep.Delete(deleteUser);
                    await _db.SaveChangesAsync(this.User.FindFirst("UserID").Value);
                    return Ok(true);
                }
                if (deleteUser.UserRole.UserRoleId == 2)
                {
                    _rep.ReplaceRefferralCodes(deleteUser.Id);
                    _rep.Delete(deleteUser);
                    await _db.SaveChangesAsync(this.User.FindFirst("UserID").Value);
                    return Ok(true);
                }
                return Ok(true);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }

        }

        [HttpPost("Email")]
        public async Task<ActionResult> Email( string emailto, string name, string surname, string username, string password)
        {
            var apiKey = "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";
            var client = new SendGridClient(apiKey);
            var from = new EmailAddress("saicsinnovations@gmail.com", "Saics Innovations");
            var subject = "Registration";
            var to = new EmailAddress(emailto);
            var plainTextContent = "and easy to do anywhere, even with C#";
            var htmlContent = $"<h2><b>Welcome to SAiCS Innovations {name + ' ' + surname}!</b></h2><br> We are pleased to have you part of our company. Get ready to make some real money ;-) <br> Your login credentials are as follows:<br>" +
                $"Username: {username} <br>" +
                $"Password: {password}";
            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            var response = await client.SendEmailAsync(msg);
            return Ok(true);
        }
        [HttpPost("ResetPasswordEmail")]
        public async Task<ActionResult> ResetPasswordEmail(string emailto, string name, string surname, string username, string password)
        {
            var apiKey = "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";
            var client = new SendGridClient(apiKey);
            var from = new EmailAddress("saicsinnovations@gmail.com", "Saics Innovations");
            var subject = "Password Reset";
            var to = new EmailAddress(emailto);
            var plainTextContent = "and easy to do anywhere, even with C#";
            var htmlContent = $"<h2><b>Greetings {name + ' ' + surname}!</b></h2><br> Your password has been reset at {DateTime.UtcNow} <br> Your new Login credentials are as follows:<br>" +
                $"Username: {username} <br>" +
                $"Password: {password}";
            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            var response = await client.SendEmailAsync(msg);
            return Ok(true);
        }

        [HttpPost("SendSMS")]
        public ActionResult SendSMS(string sender, string smsMessage)
        {
            var accSid = "AC7ed5f3a417819cf64200e56e92fdaea2";
            var authToken = "35a18ea162053ed84c6f02febd33054a";
            TwilioClient.Init(accSid, authToken);
            var to =  new PhoneNumber(sender);
            var from = "+12242191485";

            var message = MessageResource.Create(to: to, from: from, body: smsMessage);
            return Ok("sent");
        }

        [HttpPost("ForgotPassword")]
        public async Task<ActionResult> ForgotPassword(LoginVM email)
        {
            try
            {
                //find user in databse
                //var user = _db.Users.Where(Email => Email.Email == email || Email.UserName == email).FirstOrDefault();
                var user = await _manager.FindByNameAsync(email.EmailorUsername);
                
                if (user != null)
                {
                    var userInfo = _db.Users.Where(id => id.Id == user.Id).Include(role => role.UserRole).FirstOrDefault();
                    //set otp information
                    var otp = _rep.GenerateOTP();
                    var usersOTP = _db.Passwords.Where(id => id.UserId == user.Id).FirstOrDefault();
                    usersOTP.OtpexpireTime = DateTime.Now.AddHours(2);
                    usersOTP.HashedOtp = BCrypt.Net.BCrypt.HashPassword(otp);
                    await _db.SaveChangesAsync(userInfo.Id);

                    //Send OTP to user
                    SendSMS($"+27{user.PhoneNumber}", $"Greetings {user.Name} {user.Surname}!  The following is your OTP pin : {otp}  This OTP Pin will expire at {usersOTP.OtpexpireTime}");
                    //Email("Reset password OTP PIN", "Greetings! The following is your OTP pin : " + otp+". This OTP Pin will expire at "+ usersOTP.OtpexpireTime, "u20551313@tuks.co.za");
                    var token = _rep.GenerateToken(userInfo);
                    return Ok(token);
                }
                else
                {
                    return NotFound("User does not exist!");
                }
                
            }
            catch(Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("VerifyOTP")]
        public ActionResult VerifyOTP(string otp)
        {
            if (_rep.VerifyOTP(this.User.FindFirst("UserID").Value,otp) == true)
            {
                return Ok(true);
            }
            else
            {
                return NotFound("Incorrect OTP");
            }
        }

        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("ResetPassword")]
        public async Task<ActionResult> ResetPassword(string resetPassword)
        {
            //users information
            var user = _db.Users.Where(id => id.Id == this.User.FindFirst("UserID").Value).FirstOrDefault();
            //Save the new password to the database
            var usersPassword = _db.Passwords.Where(id => id.UserId == this.User.FindFirst("UserID").Value).FirstOrDefault();
            usersPassword.Password1 = BCrypt.Net.BCrypt.HashPassword(resetPassword);
            usersPassword.OtpexpireTime = null;
            usersPassword.HashedOtp = null;
            await _db.SaveChangesAsync(this.User.FindFirst("UserID").Value);
            await this.ResetPasswordEmail(user.Email, user.Name, user.Surname, user.UserName, resetPassword);
            return Ok(true);
        }

        //Get session info after logged in's info
        [HttpPost("getUserSessionInfo")]
        public object getUserSessionInfo(LoginVM logindetails)
        {
            try
            {
                var user = _rep.getUserSessionInfo(logindetails);
                return user;
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        //getting ambassadors and admin application status
        [HttpGet("applicationStatus")]
        public ActionResult applicationStatus(string id)
        {
            try
            {
                var application = _rep.ApplicationStatus(id);
                return Ok(application);
            }
            catch(Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, error.InnerException.Message);
            }
        }
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        //Update user profile
        [HttpPatch("updateUser")]
        public async Task<ActionResult> updateUser(ProfileVM user)
        {
            try
            {
                _rep.UpdateUser(user);
                await _db.SaveChangesAsync(this.User.FindFirst("UserID").Value);
                var results = _db.Users.Where(id => id.Id == user.Id).Include(address => address.Addresses)
                                                                        .ThenInclude(country => country.Country)
                                                                        .Include(title => title.Title)
                                                                        .Include(userrole => userrole.UserRole)
                                                                        .Include(refferral => refferral.Referrals)
                                                                        .ThenInclude(code => code.ReferralCode)
                                                                        .Include(address => address.Addresses)
                                                                        .ThenInclude(province => province.Province)
                                                                        .FirstOrDefault();
                return Ok(results);
                
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, error.InnerException.Message);
            }
        }

        ////////
        ///AMANDA CODE
        ///////
        ///
        [HttpGet("GetSecondaryAddress")]
        public object GetSecondaryAddress(string id)
        {
            try
            {
                return _rep.GetSecondaryAddress(id);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpPost("AddSecondaryAddress")]
        public object AddSecondaryAddress(Address address)
        {
            try
            {
                return _rep.AddSecondaryAddress(address);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpGet("GetProvinces")]
        public object GetProvinces()
        {
            try
            {
                return _rep.GetAll<Province>();
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }


        [HttpGet("GetSecondaryAddressById")]
        public object GetSecondaryAddressById(int id)
        {
            try
            {

                return _rep.GetSecondaryAddressById(id);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpPut("EditSecondaryAddress")]
        public object EditSecondaryAddress(Address address)
        {
            try
            {

                return _rep.EditSecondaryAddress(address);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpDelete("DeleteSecondaryAddress")]
        public object DeleteSecondaryAddress(int id)
        {
            try
            {

                return _rep.DeleteSecondaryAddress(id);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("GetAssociatedAmbassador")]
        public object GetAssociatedAmbassador(string id)
        {
            try
            {

                return _rep.GetAssociatedAmbassador(id);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("ViewCatalog")]
        public object ViewCatalog()
        {
            try
            {
                return _rep.ViewCatalog();
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }

        }

        [HttpGet("ViewCatalogItem")]
        public object ViewCatalogItem(int id)
        {
            try
            {
                return _rep.ViewCatalogItem(id);
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }

        }

        [HttpGet("ViewCatelogSpecials")]
        public object ViewCatelogSpecials()
        {
            try
            {
                return _rep.GetAllSpecials();
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }

        }

        [HttpGet("GetVAT")]
        public object GetVAT()
        {
            try
            {
                return _rep.GetVAT();
            }
            catch
            {
                return false;
            }

        }

        [HttpGet("AgentAccountInfo")]
        public object AgentAccountInfo(string id)
        {
            try
            {
                return _rep.AgentAccountInfo(id);
            }
            catch
            {
                return false;
            }

        }




        //[HttpGet("LoggedInName")]
        //public object LoggedInName()
        //{
        //    try
        //    {
        //        //var user = await _manager.FindByNameAsync(email);
        //        return _rep.LoggedInName(this.User.FindFirst("UserID").Value);
        //    }
        //    catch (Exception error)
        //    {
        //        return BadRequest(error.Message);
        //    }

        //}

        ////////
        ///AMANDA CODE
        ///////
        ///

    }
}
