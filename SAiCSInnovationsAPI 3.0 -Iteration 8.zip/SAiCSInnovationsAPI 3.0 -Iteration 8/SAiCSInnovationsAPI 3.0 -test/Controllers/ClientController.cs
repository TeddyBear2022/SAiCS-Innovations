﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SAiCSInnovationsAPI_3._0.Models;
using SAiCSInnovationsAPI_3._0.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;

namespace SAiCSInnovationsAPI_3._0.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "Client")]
    public class ClientController : ControllerBase
    {
        private readonly ISAiCSInnovationsRep _rep;
        private readonly SaicsInnovationsDBContext _db;
        public ClientController(ISAiCSInnovationsRep rep, SaicsInnovationsDBContext db)
        {
            _rep = rep;
            _db = db;
        }

        [HttpGet("PurchasedProducts")]
        public object PurchasedProducts()
        {
            try
            {

                return _rep.PurchasedProducts(this.User.FindFirst("UserID").Value);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("GetMerchCats")]
        public object GetMerchCats()
        {
            try
            {
                return _rep.GetAll<MerchCategory>();
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }

        }

        //Creating feedback
        [HttpPost("CreateFeedback")]
        public async Task<ActionResult> CreateFeedback(string userId, Feedback feedback)
        {
            try
            {
                if (_rep.AddFeedback(userId, feedback))
                {
                    await _db.SaveChangesAsync(this.User.FindFirst("UserID").Value);
                }
                return Ok(true);
                

            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        //[HttpGet("ViewFeedback")]
        //public object ViewFeedback(string id)
        //{
        //    try
        //    {

        //        return _rep.ViewFeedback(id);
        //    }
        //    catch (Exception error)
        //    {
        //        return BadRequest(error.InnerException.Message);
        //    }
        //}

        // Delete feedback
        [HttpDelete("DeleteFeedback")]
        public  ActionResult DeleteFeedback(int id)
        {
            try
            {
                if (_rep.DeleteFeedback(id) == true)
                {
                    _rep.SaveChanges();
                    //await _db.SaveChangesAsync(this.User.FindFirst("UserID").Value);
                    return Ok(true);
                }
                else
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "Internal server error`");
                }

            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        // Get product feedback
        [HttpGet("GetProductFeedback")]
        public object GetProductFeedback(string id)
        {
            try
            {
                return _rep.GetProductFeedbacks(id);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        // Get ambassador feedback
        [HttpGet("GetAmbassadorFeedback")]
        public object GetAmbassadorFeedback(string id)
        {
            try
            {
                return _rep.GetAmbassadorFeedbacks(id);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        //Get Account category FAQs
        //[HttpGet("GetAccountFAQ")]
        //public object GetAccountFAQ()
        //{
        //    try
        //    {
        //        return _rep.GetAccountFAQs();
        //    }
        //    catch (Exception error)
        //    {
        //        return BadRequest(error.InnerException.Message);
        //    }
        //}
        //Get Product FAQ 
        //[HttpGet("GetProductFAQ")]
        //public object GetProductFAQ()
        //{
        //    try
        //    {
        //        return _rep.GetProductFAQs();
        //    }
        //    catch (Exception error)
        //    {
        //        return BadRequest(error.InnerException.Message);
        //    }
        //}

        //Get Delivery FAQ 
        //[HttpGet("GetDeliveryFAQ")]
        //public object GetDeliveryFAQ()
        //{
        //    try
        //    {
        //        return _rep.GetDeliveryFAQs();
        //    }
        //    catch (Exception error)
        //    {
        //        return BadRequest(error.InnerException.Message);
        //    }
        //}

        //Get ambassador assigned to users information
        //[HttpGet("MyAmbassador")]
        //public object GetMyAmbassador(int id)
        //{
        //    try
        //    {
        //        return _rep.MyAmbassador(id);
        //    }
        //    catch (Exception error)
        //    {
        //        return BadRequest(error.InnerException.Message);
        //    }
        //}

        //Get Catalog by category
        //[HttpGet("GetCatalogByCategory")]
        //public object GetCatalogByCategory(int id)
        //{
        //    try
        //    {
        //        return _rep.GetCatalogByCategory(id);
        //    }
        //    catch (Exception error)
        //    {
        //        return BadRequest(error.InnerException.Message);
        //    }
        //}
    }
}
