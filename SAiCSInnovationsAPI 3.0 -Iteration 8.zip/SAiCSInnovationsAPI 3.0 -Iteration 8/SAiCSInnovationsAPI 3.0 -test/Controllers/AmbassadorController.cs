﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using SAiCSInnovationsAPI_3._0.Models;
using SAiCSInnovationsAPI_3._0.Repository;
using SAiCSInnovationsAPI_3._0.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;

namespace SAiCSInnovationsAPI_3._0.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "Ambassador")]
    public class AmbassadorController : ControllerBase
    {
        private readonly ISAiCSInnovationsRep _rep;
        private readonly SaicsInnovationsDBContext _db;
        private readonly UserManager<User> _manager;
        private readonly IUserClaimsPrincipalFactory<User> _claims;
        private readonly IConfiguration _configuration;
        // public int otp = 0;

        public AmbassadorController(UserManager<User> manager,
            IUserClaimsPrincipalFactory<User> claims,
            IConfiguration configuration,
            ISAiCSInnovationsRep rep,
             SaicsInnovationsDBContext db
            )
        {
            _manager = manager;
            _claims = claims;
            _configuration = configuration;
            _rep = rep;
            _db = db;

        }

        //[HttpPost("GetRefferralCode")]
        //public object GetRefferralCode(string name, string surname)
        //{
        //    var newRefferralCode = _rep.GenerateRefferralCode(name, surname);
        //    return newRefferralCode;
        //}
        [AllowAnonymous]
        [HttpGet("BankInputInfo")]
        public ActionResult BankNames()
        {
            BankInputVM bankInputInfo = new BankInputVM();
            bankInputInfo.BankNames = _db.Banks.ToList();
            bankInputInfo.AccountTypesNames = _db.AccountTypes.ToList();

            return Ok(bankInputInfo);
        }

        [HttpPatch("UpdateBankDetails")]
        public ActionResult UpdateBankDetails(BankAccount updateB)
        {
            try
            {
                var usersAccount = _db.BankAccounts.Where(b => b.BankAccountId == updateB.BankAccountId).FirstOrDefault();
                usersAccount.AccountTypeId = updateB.AccountTypeId;
                usersAccount.BankId = updateB.BankId;
                usersAccount.AccountNumber = updateB.AccountNumber;
                usersAccount.AccountHolder = updateB.AccountHolder;
                _rep.SaveChanges();
                return Ok(true);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("ViewCurrentClients")]
        public ActionResult ViewCurrentClients()
        {
            try
            {
                var listOfClients = _rep.ViewCurrentClients(this.User.FindFirst("UserID").Value);

                return Ok(listOfClients);
            }
            catch(Exception ex)
            {
                return BadRequest(ex.InnerException.Message);
            }
        }

        [HttpGet("GetAmbassadorFAQS")]
        public ActionResult GetAmbassadorFAQS()
        {
            //var faqs = _db.Faqtypes.Where(amb => amb.FaqtypeId == 2).Include(cat => cat.Faqcategories).ThenInclude(faq => faq.Faqs).ToList();
            var ambFaqs = _db.Faqcategories.Where(type => type.FaqtypeId == 2).ToList();
            return Ok(ambFaqs);
        }

        [HttpGet("GetSpecificFaq")]
        public ActionResult GetSpecificFaq(int categoryID)
        {
            var faqs = _db.Faqs.Where(catId => catId.FaqcategoryId == categoryID).Include(cat => cat.Faqcategory).ToList();
            return Ok(faqs);
        }

        //[HttpGet("AccountTypeNames")]
        //public ActionResult AccountTypeNames()
        //{
        //    var accountNames = _db.AccountTypes.ToList();
        //    return Ok(accountNames);
        //}

        [HttpPost("ViewCurrentAgents")]
        public object ViewCurrentAgents(credentialsVM credentials)
        {
            var listOfAgents = _rep.ViewCurrentAgents(credentials.userID);

            return listOfAgents;
        }

        [HttpPost("PromotionRequest")]
        public object PromotionRequest(string userID)
        {
            var positionRequest = _rep.RequestRankingPromotion(userID);
            if (positionRequest == true)
            {
                return "Promotion request completed";
            }
            else
            {
                return "Promotion request incomplete";
            }

        }

        [HttpPost("DemotionRequest")]
        public object DemotionRequest(string userID)
        {
            var positionRequest = _rep.RequestRankingDemotion(userID);
            if (positionRequest == true)
            {
                return "Promotion request completed";
            }
            else
            {
                return "Promotion request incomplete";
            }

        }

        [HttpPost("ViewFAQ")]
        public object ViewFAQ()
        {
            return "Stub";
        }

        [HttpPost("ViewClients")]
        public object ViewClients(credentialsVM credentials)
        {
            var clients = _rep.ViewClient(credentials.userID);

            return clients;
        }

        [HttpPost("ViewClientOrders")]
        public object ViewClientOrders()
        {
            return "Stub";
        }

        [HttpPost("ViewAmbassadorFeedback")]
        public object ViewAmbassadorFeedback(string userID)
        {
            var feedbacks = _rep.ViewAmbassadorFeedback(userID);
            return feedbacks;
        }

        [HttpPost("SearchAmbassadorFeedback")]
        public object SearchAmbassadorFeedback()
        {

            return "Stub";
        }

        [HttpPost("ViewPerformance")]
        public object ViewPerformance()
        {

            return "Stub";
        }

        [HttpGet("SearchCurrentAgents")]
        public ActionResult SearchCurrentAgents(string userid, string searchInput)
        {
            try
            {
                var searchedAmbassadors = _rep.SearchCurrentAgents(userid, searchInput);
                if (searchedAmbassadors == "Not Found")
                {
                    return NotFound("Ambassador not found");
                }
                return Ok(searchedAmbassadors);
            }
            catch(Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("AmbassadorsByType")]
        public ActionResult AmbassadorByType(int ambType)
        {
            try
            {
                var filteredAmbassador = _db.Ambassadors
                   .Include(user => user.User)
                   .Include(user => user.User).ThenInclude(title => title.Title)
                   .Include(type => type.AmbassadorType).Where(type => type.AmbassadorTypeId == ambType)
                   .ToList();

                return Ok(filteredAmbassador);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }


        ////////
        ///AMANDA CODE
        ///////
        ///

        [HttpGet("ViewSalesOrder")]
        public  ActionResult ViewSalesOrder()
        {
            try
            {
                var orders = _rep.ViewSalesOrder(this.User.FindFirst("UserID").Value);
                if (orders == null)
                {
                    return StatusCode(204, "Null");
                }


                return Ok(orders);
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpGet("SalesOrderDetails")]
        public ActionResult SalesOrderDetails(int id)
        {
            try
            {
                var order = _rep.SalesOrderDetails(id);
                if (order == null)
                {
                    return StatusCode(204, "Null");
                }
                else
                {
                    return Ok(order);
                }
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpPut("UpdateSalesOrderStatus")]
        public async Task<ActionResult> UpdateSalesOrderStatus(UpdateOrderVM update)
        {
            try
            {
                if (_rep.UpdateSalesOrderStatus(update) == true)
                {
                    await _db.SaveChangesAsync(this.User.FindFirst("UserID").Value);
                    return Ok(true);
                }
                else
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "Internal server error`");
                }


            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }

        }

        [HttpGet("GetAllOrderStatuses")]
        public ActionResult GetAllOrderStatuses()
        {
            try
            {
                var order = _rep.GetAll<OrderStatus>();

                if (order == null)
                {
                    return StatusCode(204, "Null");
                }
                else
                {
                    return Ok(order);
                }

            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpGet("SalesOrderById")]
        public ActionResult SalesOrderById(int id)
        {
            try
            {
                var order = _rep.SalesOrderById(id);
                if (order == null)
                {
                    return StatusCode(204, "Null");
                }
                else
                {
                    return Ok(order);
                }
            }
            catch
            {
                return BadRequest();
            }
        }

        ////////
        ///AMANDA CODE
        ///////
        ///
    }
}
