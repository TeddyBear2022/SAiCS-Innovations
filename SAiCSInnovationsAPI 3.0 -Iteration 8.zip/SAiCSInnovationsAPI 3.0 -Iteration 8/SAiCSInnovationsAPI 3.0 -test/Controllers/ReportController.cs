﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SAiCSInnovationsAPI_3._0.Repository;
using SAiCSInnovationsAPI_3._0.ViewModels;
using System.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAiCSInnovationsAPI_3._0.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "Admin")]
    public class ReportController : ControllerBase
    {
        private readonly ISAiCSInnovationsRep _rep;
        public ReportController(ISAiCSInnovationsRep rep)
        {
            _rep = rep;
        }

        [HttpGet("ProductListRep")]
        public object ProductListRep(int type, int category)
        {
            try
            {
                var result = _rep.GetProductList(type, category);
                if (result == null)
                {
                    return StatusCode(204, "Null");
                }


                return Ok(result);

            }
            catch
            {
                return false;
            }
            
        }

        [HttpGet("AmbassadorListRep")]
        public object AmbassadorListRep(int province, int ranking)
        {
            try
            {
                var result = _rep.AmbassadorListRep(province, ranking);
                if (result == null)
                {
                    return StatusCode(204, "Null");
                }


                return Ok(result);
                
            }
            catch
            {
                return false;
            }
        }

        [HttpGet("TopSeller")]
        public object TopSeller(int province, int ranking)
        {
            try
            {
                var result = _rep.TopSeller(province, ranking);
                if (result == null)
                {
                    return StatusCode(204, "Null");
                }


                return Ok(result);

            }
            catch
            {
                return false;
            }
        }

        [HttpGet("TargetRep")]
        public object TargetRep(DateTime From, DateTime To)
        {
            try
            {
                var result = _rep.TargetRep(From, To);
                if (result == null)
                {
                    return StatusCode(204, "Null");
                }


                return Ok(result);

            }
            catch
            {
                return false;
            }
        }


        [HttpGet("RecruitmentRep")]
        public object RecruitmentRep(int month)
        {
            try
            {
                var result = _rep.RecruitmentRep(month);
                if (result == null)
                {
                    return StatusCode(204, "Null");
                }


                return Ok(result);

            }
            catch
            {
                return false;
            }
        }

        [HttpPost("TopProduct")]
        public object TopProduct(SalesRepForm salesRep)
        {
            try
            {
                var result = _rep.TopProduct(salesRep);
                if (result == null)
                {
                    return StatusCode(204, "Null");
                }


                return Ok(result);

            }
            catch
            {
                return false;
            }
        }

        [HttpPost("SalesRep")]
        public object SalesRep(SalesRepForm salesRep)
        {
            try
            {
                var result = _rep.SalesRep(salesRep);
                if (result == null)
                {
                    return null;
                }
                //JsonValue value = JsonValue.Parse((string)result);
                //JsonObject send = value as JsonObject;
                return result;
            }
            catch
            {
                return false;
            }
        }
    }
}
