﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SAiCSInnovationsAPI_3._0.Repository;
using SAiCSInnovationsAPI_3._0.Models;
using Microsoft.EntityFrameworkCore;
using System.Net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System.Security.Claims;
using SAiCSInnovationsAPI_3._0.ViewModels;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace SAiCSInnovationsAPI_3._0.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "Admin")]
    public class AdminController : ControllerBase
    {
        private readonly SaicsInnovationsDBContext _db;
        private readonly ISAiCSInnovationsRep _rep;
        public AdminController(ISAiCSInnovationsRep rep, SaicsInnovationsDBContext db)
        {
            _rep = rep;
            _db = db;
        }

        //get all titles
        [HttpGet("getTitles")]
        public object GetTitles()
        {
            try
            {
                return _rep.GetTitles();
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }

        }

        [HttpGet("SearchAmbassadorReg")]
        public ActionResult SearchAmbassadorReg(string nameorsurname)
        {
            try
            {
                var applications = _db.Applications.Where(status => status.ApplicationStatusId == 1).Include(user => user.User).Where(d => d.User.Name.Contains(nameorsurname) || d.User.Surname.Contains(nameorsurname)).ToList();
                List<User> applicantsDetails = new List<User>();
                for (var x = 0; x <= applications.Count() - 1; x++)
                {
                    var applicant = _db.Users.Where(id => id.Id == applications[x].UserId && id.UserRoleId == 2)
                         .Include(amb => amb.Ambassadors)
                         .ThenInclude(role => role.AmbassadorType)
                         .Include(t => t.Title)
                         .FirstOrDefault();
                    applicantsDetails.Add(applicant);
                }


                if (applicantsDetails.Count() == 0)
                {
                    return NotFound("Can't find ambassador");
                }
                return Ok(applicantsDetails);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        //Get user roles
        [HttpGet("GetUserRoles")]
        public object GetUserRoles()
        {
            try
            {
                return _rep.GetUserRoles();
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }

        }
        //Get countries
        [HttpGet("getCountry")]
        public object GetCountry()
        {
            try
            {
                return _rep.GetCountry();
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }

        }

        //Creating a FAQ
        [HttpPost("createFAQ")]
        public async Task<ActionResult> createFAQ(Faq faq)
        {
            try
            {
                _rep.Add(faq);
                await _db.SaveChangesAsync(this.User.FindFirst("UserID").Value);
                //_rep.SaveChanges();
                return Ok(true);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("AuditTrail")]
        public ActionResult AuditTrail()
        {
            try
            {
                var auditlog = _db.AuditTrails.ToList();
                return Ok(auditlog);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("AuditTrailByTransactionType")]
        public ActionResult AuditTrailByTransactionType(string type)
        {
            try
            {

                var auditLog = _db.AuditTrails.Where(transaction => transaction.TransactionType == type).ToList();

                return Ok(auditLog);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);

            }
        }

        //Get Ambassador Types
        [HttpGet("getAmbassadorTypes")]
        public object GetAmbassadorTypes()
        {
            try
            {
                return _rep.GetAmbassadorTypes();
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        [HttpGet("GetAmbassadorRankings")]
        public ActionResult GetAmbassadorRankings()
        {
            try
            {
                var ambRankings = _db.AmbassadorTypes.ToList();
                return Ok(ambRankings);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpPost("UpdateAmbassadorDiscounts")]
        public async Task<ActionResult> UpdateAmbassadorDiscounts(AmbassadorType ambType)
        {
            try
            {
                var updateType = _db.AmbassadorTypes.Where(id => id.AmbassadorTypeId == ambType.AmbassadorTypeId).FirstOrDefault();
                updateType.DiscountPercentage = ambType.DiscountPercentage;
                await _db.SaveChangesAsync(this.User.FindFirst("UserID").Value);
                return Ok();
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        private async Task<ActionResult> SuccessEmail(string emailto, string name, string surname)
        {
            var apiKey = "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";
            var client = new SendGridClient(apiKey);
            var from = new EmailAddress("saicsinnovations@gmail.com", "Saics Innovations");
            var subject = "Good news!!!";
            var to = new EmailAddress(emailto);
            var plainTextContent = "and easy to do anywhere, even with C#";
            var htmlContent = $"<h2><b> {name + ' ' + surname} SAiCs Application!</b></h2><br> We are pleased to alert you that after careful vetting, your application has been accepted and are now able to access your account on the system :-). <br> Regards,<br>SAiCs";
            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            var response = await client.SendEmailAsync(msg);
            return Ok(true);
        }

        async Task<ActionResult> UnSuccessEmail(string emailto, string name, string surname)
        {
            var apiKey = "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";
            var client = new SendGridClient(apiKey);
            var from = new EmailAddress("saicsinnovations@gmail.com", "Saics Innovations");
            var subject = "Application status!!!";
            var to = new EmailAddress(emailto);
            var plainTextContent = "and easy to do anywhere, even with C#";
            var htmlContent = $"<h2><b> {name + ' ' + surname} SAiCs Application!</b></h2><br> We are sad to inform you that after careful vetting, your application has been rejected and will not have access your account on the system :-(. <br> Regards,<br>SAiCs";
            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, htmlContent);
            var response = await client.SendEmailAsync(msg);
            return Ok(true);
        }

        [HttpPost("AccceptRegistration")]
        public async Task<ActionResult> AccceptRegistration(Application applicationRequest)
        {
            try
            {
                var application = _db.Applications.Where(id => id.ApplicationId == applicationRequest.ApplicationId).FirstOrDefault();
                var user = _db.Users.Where(u => u.Id == applicationRequest.UserId).FirstOrDefault();
                application.ApplicationStatusId = 2;
                application.Date = DateTime.UtcNow;
                await SuccessEmail(user.Email, user.Name, user.Surname);
                await _db.SaveChangesAsync(this.User.FindFirst("UserID").Value);
                return Ok(true);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpPost("RejectRegistration")]
        public async Task<ActionResult> RejectRegistration(Application applicationRequest)
        {
            try
            {
                var application = _db.Applications.Where(id => id.ApplicationId == applicationRequest.ApplicationId).FirstOrDefault();
                var user = _db.Users.Where(u => u.Id == applicationRequest.UserId).FirstOrDefault();
                application.ApplicationStatusId = 3;
                application.Date = DateTime.UtcNow;
                await UnSuccessEmail(user.Email, user.Name, user.Surname);
                await _db.SaveChangesAsync(this.User.FindFirst("UserID").Value);
                return Ok(true);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        //Deleting a FAQ
        [HttpDelete("deleteFAQ")]
        public ActionResult deleteFAQ(int faqID)
        {
            try
            {
                var deleteFaq = _rep.FindFAQ(faqID);
                _rep.Delete(deleteFaq);
                _rep.SaveChanges();
                return Ok(true);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        //Get all FAQs
        [HttpGet("getAllFAQS")]
        public object getAllFAQS()
        {
            try
            {
                var faqs = _rep.getAllFAQs();
                return faqs;
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        //Get faq categories
        [HttpGet("getFAQCategories")]
        public object getFAQCategories()
        {
            try
            {
                var categories = _rep.GetFAQCategories();
                return categories;
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpPost("createFAQCategory")]
        public object createFAQCategory(Faqcategory faqcategory)
        {
            try
            {
                _rep.Add(faqcategory);
                _rep.SaveChanges();
                return true;
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpDelete("deleteFAQCategory")]
        public ActionResult deleteFAQCategory(int faqCategoryID)
        {
            try
            {
                
                _rep.deleteFAQCategory(faqCategoryID);
                _rep.SaveChanges();
                return Ok(true);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpPatch("updateFAQ")]
        public ActionResult updateFAQ(Faq faq)
        {
            try
            {
                if (_rep.updateFAQ(faq) == true)
                {
                    _rep.SaveChanges();
                    return Ok(true);
                }
                else
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "Internal server error`");
                }


            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("PositionRequests")]
        public ActionResult PositionRequests()
        {
            try
            {
                var requests = _rep.PositionRequests();
                return Ok(requests);
            }
            catch (Exception error)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, error.InnerException.Message);
            }
        }

        //Targets
        [HttpPost("CreateTarget")]
        public async Task<ActionResult> CreateTarget(Target target)
        {
            try
            {
                var existingTarget = _db.Targets.Where(t => t.AmbassadorId == target.AmbassadorId).FirstOrDefault();

                if (existingTarget != null)
                {
                    return NotFound("Target Exists");
                }
                _rep.Add(target);
                await _db.SaveChangesAsync(this.User.FindFirst("UserID").Value);
                return Ok(true);

            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }

        }
        [HttpPatch("UpdateTarget")]
        public async Task<ActionResult> UpdateTarget(Target target)
        {
            try
            {
                var updateTarget = _db.Targets.Where(id => id.AmbassadorId == target.AmbassadorId).FirstOrDefault();
                updateTarget.Target1 = target.Target1;
                updateTarget.StartDate = target.StartDate;
                updateTarget.EndDate = target.EndDate;
                await _db.SaveChangesAsync(this.User.FindFirst("UserID").Value);
                return Ok(true);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }

        }
        [HttpGet("GetAllTarget")]
        public ActionResult GetAllTarget()
        {
            try
            {
                List<UserTargetVM> distributorsTargets = new List<UserTargetVM>();
                var distributors = _db.Ambassadors.Where(type => type.AmbassadorTypeId == 6 || type.AmbassadorTypeId == 7 || type.AmbassadorTypeId == 8)
                    .Include(user => user.User)
                    .Include(role => role.AmbassadorType)
                    .ToList();

                for (var x = 0; x <= distributors.Count() - 1; x++)
                {
                    UserTargetVM appendDistributors = new UserTargetVM();
                    appendDistributors.Distributor = distributors[x];
                    appendDistributors.Target = _db.Targets.Where(id => id.AmbassadorId == distributors[x].AmbassadorId).FirstOrDefault();
                    distributorsTargets.Add(appendDistributors);
                }

                return Ok(distributorsTargets);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("GetSpecificTarget")]
        public ActionResult GetSpecificTarget(int ambassadorId)
        {
            try
            {
                var target = _db.Targets.Where(id => id.AmbassadorId == ambassadorId).FirstOrDefault();
                if (target == null)
                {
                    return NotFound("Target doesnt exist");
                }

                return Ok(target);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("TargetExists")]
        public ActionResult TargetExists(int ambId)
        {
            try
            {
                var target = _db.Targets.Where(id => id.AmbassadorId == ambId).FirstOrDefault();
                if (target == null)
                {
                    return Ok(false);
                }


                return Ok(true);
            }
            catch
            {
                return BadRequest();
            }
        }

        [HttpDelete("DeleteTarget")]
        public ActionResult DeleteTarget(int targetID)
        {
            try
            {
                var deleteTarget = _db.Targets.Where(id => id.TargetId == targetID).FirstOrDefault();
                _rep.Delete(deleteTarget);
                _rep.SaveChanges();
                return Ok(true);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }


        [HttpGet("ViewFeedback")]
        public ActionResult ViewFeedback()
        {
            try
            {
                var allfeedbacks = _db.Feedbacks.Include(amb => amb.Ambassador)
                    .ThenInclude(user=>user.User)
                    .Include(merch=>merch.Merchandise)
                    .ToList();
                return Ok(allfeedbacks);

            }
            catch(Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("ViewAmbassadorFeedback")]
        public ActionResult ViewAmbassadorFeedback()
        {
            try
            {
                var ambassadorfeedbacks = _db.Feedbacks.Where(ambassadors => ambassadors.AmbassadorId != null)
                    .Include(amb => amb.Ambassador)
                    .ThenInclude(user => user.User)                    
                    .ToList();
                return Ok(ambassadorfeedbacks);

            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("ViewMerchFeedback")]
        public ActionResult ViewMerchFeedback()
        {
            try
            {
                var ambassadorfeedbacks = _db.Feedbacks.Where(merchandise => merchandise.MerchandiseId != null)
                    .Include(merch => merch.Merchandise).ThenInclude(type => type.MerchType)
                    .Include(merch => merch.Merchandise).ThenInclude(category => category.MerchCategory)                    
                    .ToList();
                return Ok(ambassadorfeedbacks);

            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("ViewAmbassadors")]
        public ActionResult ViewAmbassadors()
        {
            try
            {
                var allambassadors = _db.Ambassadors
                    .Include(user => user.User)
                    .ThenInclude(title => title.Title)
                    .Include(type => type.AmbassadorType)
                    .ToList();

                return Ok(allambassadors); 
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("SearchAmbassador")]
        public ActionResult SearchAmbassador(string nameorsurname)
        {
            try
            {
                var searchResults = _db.Ambassadors
                    .Include(user => user.User)
                    .Include(user => user.User).ThenInclude(title => title.Title)
                    .Include(type => type.AmbassadorType)
                    .Include(user => user.User).Where(searchInfo => searchInfo.User.Name.Contains(nameorsurname) || searchInfo.User.Surname.Contains(nameorsurname))
                    .ToList();

            
                if (searchResults.Count() == 0)
                {
                    return NotFound("Can't find ambassador");
                }
                return Ok(searchResults);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("GetAllRegistrations")]
        public ActionResult GetAllRegistrations()
        {
            try
            {
                var applications = _db.Applications.Where(status => status.ApplicationStatusId == 1).ToList();
                List<User> applicantsDetails = new List<User>();
                for (var x = 0; x <= applications.Count() - 1; x++)
                {
                    var applicant = _db.Users.Where(id => id.Id == applications[x].UserId && id.UserRoleId == 2)
                         .Include(amb => amb.Ambassadors)
                         .ThenInclude(role => role.AmbassadorType)
                         .Include(t => t.Title)
                         .FirstOrDefault();
                    applicantsDetails.Add(applicant);
                }

                return Ok(applicantsDetails);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("SpecificRegistrationInfo")]
        public ActionResult SpecificRegistrationInfo(string regId)
        {
            try
            {
                var applicant = _db.Users.Where(id => id.Id == regId && id.UserRoleId == 2)
                       .Include(amb => amb.Ambassadors)
                       .ThenInclude(role => role.AmbassadorType)
                       .Include(address => address.Addresses)
                       .ThenInclude(prov => prov.Province)
                       .Include(address => address.Addresses)
                       .ThenInclude(country => country.Country)
                       .Include(title => title.Title)
                       .FirstOrDefault();
                return Ok(applicant);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }



        ////////
        ///AMANDA CODE
        ///////
        ///
        [HttpGet("GetSpecialOptions")]
        public object GetSpecialOptions()
        {
            try
            {

                return _rep.GetSpecialOptions();
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("GetSpecialTypes")]
        public object GetSpecialTypes()
        {
            try
            {

                return _rep.GetSpecialTypes();
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("GetAllSpecials")]
        public object GetAllSpecials()
        {
            try
            {

                return _rep.GetAllSpecials();
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("GetSpecialById")]
        public object GetSpecialById(int id)
        {
            try
            {

                return _rep.GetSpecialById(id);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpPost("addSpecial")]
        public object addSpecial(SpecialVM vm)
        {
            try
            {
                return _rep.addSpecial(vm);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }


        [HttpPut("UpdateSpecial")]
        public object UpdateSpecial(SpecialVM vm)
        {
            try
            {

                return _rep.UpdateSpecial(vm);

            }
            catch (Exception)
            {
                return BadRequest("invalid form");
            }

        }

        [HttpDelete("DeleteSpecial")]
        public object DeleteSpecial(int id)
        {
            try
            {
                return _rep.DeleteSpecial(id);
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("GetAllAmbassadorTypes")]
        public object GetAllAmbassadorTypes()
        {
            try
            {

                return _rep.GetAll<AmbassadorType>();
            }
            catch (Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        [HttpGet("GetVAT")]
        public object GetVAT()
        {
            try
            {
                return _rep.GetVAT();
            }
            catch
            {
                return false;
            }

        }

       
        [HttpPut("UpdateVAT")]
        public object UpdateVAT(int id, decimal amount)
        {
            try
            {
                return _rep.UpdateVAT(id, amount);
            }
            catch
            {
                return false;
            }

        }

        ////////
        ///AMANDA CODE
        ///////
        ///


    }

}
