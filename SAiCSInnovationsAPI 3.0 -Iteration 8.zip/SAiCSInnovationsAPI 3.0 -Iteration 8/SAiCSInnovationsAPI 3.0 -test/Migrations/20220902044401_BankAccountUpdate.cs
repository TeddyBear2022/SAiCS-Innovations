﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SAiCSInnovationsAPI_3._0.Migrations
{
    public partial class BankAccountUpdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Order_Ambassador",
                table: "Order");

            migrationBuilder.AddColumn<string>(
                name: "AccountHolder",
                table: "BankAccount",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Order_AmbassadorID",
                table: "Order",
                column: "AmbassadorID");

            migrationBuilder.AddForeignKey(
                name: "FK_Order_Ambassador",
                table: "Order",
                column: "AmbassadorID",
                principalTable: "Ambassador",
                principalColumn: "AmbassadorID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Order_Ambassador",
                table: "Order");

            migrationBuilder.DropIndex(
                name: "IX_Order_AmbassadorID",
                table: "Order");

            migrationBuilder.DropColumn(
                name: "AccountHolder",
                table: "BankAccount");

            migrationBuilder.AddForeignKey(
                name: "FK_Order_Ambassador",
                table: "Order",
                column: "AddressID",
                principalTable: "Ambassador",
                principalColumn: "AmbassadorID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
