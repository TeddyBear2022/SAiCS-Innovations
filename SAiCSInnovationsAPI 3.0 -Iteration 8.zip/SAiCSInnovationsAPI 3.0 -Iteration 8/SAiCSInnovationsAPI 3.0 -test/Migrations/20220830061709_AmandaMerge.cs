﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SAiCSInnovationsAPI_3._0.Migrations
{
    public partial class AmandaMerge : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Status",
                table: "Merchandise");

            migrationBuilder.RenameColumn(
                name: "MerchCategoryId",
                table: "Merchandise",
                newName: "MerchCategoryID");

            migrationBuilder.RenameIndex(
                name: "IX_Merchandise_MerchCategoryId",
                table: "Merchandise",
                newName: "IX_Merchandise_MerchCategoryID");

            migrationBuilder.AddColumn<string>(
                name: "SpecialImage",
                table: "Special",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "AmbassadorID",
                table: "Order",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<int>(
                name: "SpecialCategoryID",
                table: "MerchSpecial",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "MerchStatusID",
                table: "Merchandise",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "MerchStatus",
                columns: table => new
                {
                    MerchStatusID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MerchStatusName = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MerchStatus", x => x.MerchStatusID);
                });

            migrationBuilder.CreateTable(
                name: "SpecialCategory",
                columns: table => new
                {
                    SpecialCategoryID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SpecialCategoryName = table.Column<string>(type: "varchar(30)", unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SpecialCategory", x => x.SpecialCategoryID);
                });

            migrationBuilder.CreateIndex(
                name: "IX_MerchSpecial_SpecialCategoryID",
                table: "MerchSpecial",
                column: "SpecialCategoryID");

            migrationBuilder.CreateIndex(
                name: "IX_Merchandise_MerchStatusID",
                table: "Merchandise",
                column: "MerchStatusID");

            migrationBuilder.AddForeignKey(
                name: "FK_Merchandise_MerchStatus",
                table: "Merchandise",
                column: "MerchStatusID",
                principalTable: "MerchStatus",
                principalColumn: "MerchStatusID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_MerchSpecial_SpecialCategory",
                table: "MerchSpecial",
                column: "SpecialCategoryID",
                principalTable: "SpecialCategory",
                principalColumn: "SpecialCategoryID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Merchandise_MerchStatus",
                table: "Merchandise");

            migrationBuilder.DropForeignKey(
                name: "FK_MerchSpecial_SpecialCategory",
                table: "MerchSpecial");

            migrationBuilder.DropTable(
                name: "MerchStatus");

            migrationBuilder.DropTable(
                name: "SpecialCategory");

            migrationBuilder.DropIndex(
                name: "IX_MerchSpecial_SpecialCategoryID",
                table: "MerchSpecial");

            migrationBuilder.DropIndex(
                name: "IX_Merchandise_MerchStatusID",
                table: "Merchandise");

            migrationBuilder.DropColumn(
                name: "SpecialImage",
                table: "Special");

            migrationBuilder.DropColumn(
                name: "SpecialCategoryID",
                table: "MerchSpecial");

            migrationBuilder.DropColumn(
                name: "MerchStatusID",
                table: "Merchandise");

            migrationBuilder.RenameColumn(
                name: "MerchCategoryID",
                table: "Merchandise",
                newName: "MerchCategoryId");

            migrationBuilder.RenameIndex(
                name: "IX_Merchandise_MerchCategoryID",
                table: "Merchandise",
                newName: "IX_Merchandise_MerchCategoryId");

            migrationBuilder.AlterColumn<int>(
                name: "AmbassadorID",
                table: "Order",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Status",
                table: "Merchandise",
                type: "varchar(5)",
                unicode: false,
                maxLength: 5,
                nullable: true);
        }
    }
}
