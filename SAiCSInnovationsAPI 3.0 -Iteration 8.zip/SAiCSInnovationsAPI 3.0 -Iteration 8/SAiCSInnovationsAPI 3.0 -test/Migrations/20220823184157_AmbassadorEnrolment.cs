﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SAiCSInnovationsAPI_3._0.Migrations
{
    public partial class AmbassadorEnrolment : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Course_CourseStatus",
                table: "Course");

            migrationBuilder.DropIndex(
                name: "IX_Course_CourseStatusID",
                table: "Course");

            migrationBuilder.DropColumn(
                name: "CourseStatusID",
                table: "Course");

            migrationBuilder.AddColumn<int>(
                name: "CourseStatusID",
                table: "AmbassadorEnrollment",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_AmbassadorEnrollment_CourseStatusID",
                table: "AmbassadorEnrollment",
                column: "CourseStatusID");

            migrationBuilder.AddForeignKey(
                name: "FK_AmbassadorEnrollment_CourseStatus",
                table: "AmbassadorEnrollment",
                column: "CourseStatusID",
                principalTable: "CourseStatus",
                principalColumn: "CourseStatusID",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AmbassadorEnrollment_CourseStatus",
                table: "AmbassadorEnrollment");

            migrationBuilder.DropIndex(
                name: "IX_AmbassadorEnrollment_CourseStatusID",
                table: "AmbassadorEnrollment");

            migrationBuilder.DropColumn(
                name: "CourseStatusID",
                table: "AmbassadorEnrollment");

            migrationBuilder.AddColumn<int>(
                name: "CourseStatusID",
                table: "Course",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Course_CourseStatusID",
                table: "Course",
                column: "CourseStatusID");

            migrationBuilder.AddForeignKey(
                name: "FK_Course_CourseStatus",
                table: "Course",
                column: "CourseStatusID",
                principalTable: "CourseStatus",
                principalColumn: "CourseStatusID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
