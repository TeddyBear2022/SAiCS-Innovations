﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SAiCSInnovationsAPI_3._0.Migrations
{
    public partial class AuditTrail : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AuditTrail_Admin",
                table: "AuditTrail");

            migrationBuilder.DropForeignKey(
                name: "FK_AuditTrail_Ambassador",
                table: "AuditTrail");

            migrationBuilder.DropIndex(
                name: "IX_AuditTrail_AdminID",
                table: "AuditTrail");

            migrationBuilder.DropIndex(
                name: "IX_AuditTrail_AmbassadorID",
                table: "AuditTrail");

            migrationBuilder.DropColumn(
                name: "AdminID",
                table: "AuditTrail");

            migrationBuilder.DropColumn(
                name: "AmbassadorID",
                table: "AuditTrail");

            migrationBuilder.DropColumn(
                name: "Audit_Log_Datestamp",
                table: "AuditTrail");

            migrationBuilder.DropColumn(
                name: "Audit_Log_Timestamp",
                table: "AuditTrail");

            migrationBuilder.RenameColumn(
                name: "Audit_Log_Description",
                table: "AuditTrail",
                newName: "Username");

            migrationBuilder.AddColumn<string>(
                name: "AffectedColumns",
                table: "AuditTrail",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "DateStamp",
                table: "AuditTrail",
                type: "date",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "NewValues",
                table: "AuditTrail",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "OldValues",
                table: "AuditTrail",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PrimaryKey",
                table: "AuditTrail",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TableName",
                table: "AuditTrail",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TransactionType",
                table: "AuditTrail",
                type: "text",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "UserID",
                table: "AuditTrail",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_AuditTrail_UserID",
                table: "AuditTrail",
                column: "UserID");

            migrationBuilder.AddForeignKey(
                name: "FK_AuditTrail_User",
                table: "AuditTrail",
                column: "UserID",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AuditTrail_User",
                table: "AuditTrail");

            migrationBuilder.DropIndex(
                name: "IX_AuditTrail_UserID",
                table: "AuditTrail");

            migrationBuilder.DropColumn(
                name: "AffectedColumns",
                table: "AuditTrail");

            migrationBuilder.DropColumn(
                name: "DateStamp",
                table: "AuditTrail");

            migrationBuilder.DropColumn(
                name: "NewValues",
                table: "AuditTrail");

            migrationBuilder.DropColumn(
                name: "OldValues",
                table: "AuditTrail");

            migrationBuilder.DropColumn(
                name: "PrimaryKey",
                table: "AuditTrail");

            migrationBuilder.DropColumn(
                name: "TableName",
                table: "AuditTrail");

            migrationBuilder.DropColumn(
                name: "TransactionType",
                table: "AuditTrail");

            migrationBuilder.DropColumn(
                name: "UserID",
                table: "AuditTrail");

            migrationBuilder.RenameColumn(
                name: "Username",
                table: "AuditTrail",
                newName: "Audit_Log_Description");

            migrationBuilder.AddColumn<int>(
                name: "AdminID",
                table: "AuditTrail",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "AmbassadorID",
                table: "AuditTrail",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "Audit_Log_Datestamp",
                table: "AuditTrail",
                type: "date",
                nullable: true);

            migrationBuilder.AddColumn<byte[]>(
                name: "Audit_Log_Timestamp",
                table: "AuditTrail",
                type: "rowversion",
                rowVersion: true,
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_AuditTrail_AdminID",
                table: "AuditTrail",
                column: "AdminID");

            migrationBuilder.CreateIndex(
                name: "IX_AuditTrail_AmbassadorID",
                table: "AuditTrail",
                column: "AmbassadorID");

            migrationBuilder.AddForeignKey(
                name: "FK_AuditTrail_Admin",
                table: "AuditTrail",
                column: "AdminID",
                principalTable: "Admin",
                principalColumn: "AdminID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_AuditTrail_Ambassador",
                table: "AuditTrail",
                column: "AmbassadorID",
                principalTable: "Ambassador",
                principalColumn: "AmbassadorID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
