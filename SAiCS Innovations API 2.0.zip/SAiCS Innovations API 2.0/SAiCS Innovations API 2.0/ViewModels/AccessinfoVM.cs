﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAiCS_Innovations_API_2._0.ViewModels
{
    public class AccessinfoVM
    {
        public string Username { get; set; }
        public string Password { get; set; }

    }
}
