﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SAiCS_Innovations_API_2._0.Models
{
    public partial class SpecialType
    {
        public SpecialType()
        {
            Specials = new HashSet<Special>();
        }

        public int SpecialTypeId { get; set; }
        public string SpecialTypeName { get; set; }

        public virtual ICollection<Special> Specials { get; set; }
    }
}
