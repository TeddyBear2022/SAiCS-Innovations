﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SAiCS_Innovations_API_2._0.Models
{
    public partial class PackageType
    {
        public PackageType()
        {
            Packages = new HashSet<Package>();
        }

        public int PackageTypeId { get; set; }
        public string PackageTypeName { get; set; }

        public virtual ICollection<Package> Packages { get; set; }
    }
}
