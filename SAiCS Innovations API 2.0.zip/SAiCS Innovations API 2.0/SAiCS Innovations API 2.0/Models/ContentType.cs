﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SAiCS_Innovations_API_2._0.Models
{
    public partial class ContentType
    {
        public ContentType()
        {
            Contents = new HashSet<Content>();
        }

        public int ContentTypeId { get; set; }
        public string ContentTypeName { get; set; }

        public virtual ICollection<Content> Contents { get; set; }
    }
}
