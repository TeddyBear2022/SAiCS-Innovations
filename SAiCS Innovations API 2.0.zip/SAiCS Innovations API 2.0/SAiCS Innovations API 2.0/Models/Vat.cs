﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SAiCS_Innovations_API_2._0.Models
{
    public partial class Vat
    {
        public int Vatid { get; set; }
        public string Description { get; set; }
        public decimal? VatPercentage { get; set; }
    }
}
