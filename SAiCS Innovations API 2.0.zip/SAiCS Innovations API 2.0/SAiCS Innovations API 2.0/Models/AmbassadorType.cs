﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SAiCS_Innovations_API_2._0.Models
{
    public partial class AmbassadorType
    {
        public AmbassadorType()
        {
            Ambassadors = new HashSet<Ambassador>();
        }

        public int AmbassadorTypeId { get; set; }
        public string AmbassadorTypeName { get; set; }

        public virtual ICollection<Ambassador> Ambassadors { get; set; }
    }
}
