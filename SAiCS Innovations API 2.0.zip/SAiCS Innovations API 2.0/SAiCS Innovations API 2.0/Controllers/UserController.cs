﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SAiCS_Innovations_API_2._0.Repository;
using SAiCS_Innovations_API_2._0.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAiCS_Innovations_API_2._0.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly ISAiCSInnovationsRep _rep;
        public UserController(ISAiCSInnovationsRep rep)
        {
            _rep = rep;
        }
        //Register User
        [HttpPost("RegisterUser")]
        public object RegisterUser(RegisterVM registration)
        {
            try
            {
                if (_rep.RegisterUser(registration) == true) 
                {
                    //Registered
                    return true;
                }
                else
                {
                    //Not registered
                    return false;
                }
            }
            catch(Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        //Get Admins
        [HttpGet("GetAllAdmins")]
        public object GetAllAdmins()
        {
            try
            {
               return  _rep.GetAllAdmins();
            }
            catch(Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        //Get Ambassadors
        [HttpGet("GetAllAmbassadors")]
        public object GetAllAmbassadors()
        {
            return _rep.GetAllAmbassadors();
        }

        //Get Clients
        [HttpGet("GetAllClients")]
        public object GetAllClients()
        {
            try
            {
                return _rep.GetAllClients();
            }
            catch(Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        //Login
        //Note revamp login and return strings to if an error pops up on teh frontend we know exctly which one to display on the alert
        [HttpPost("Login")]
        public object Login(LoginVM logindetails)
        {
            try
            {
                return _rep.Login(logindetails);
            }
            catch(Exception error)
            {
                return BadRequest(error.InnerException.Message);
            }
        }

        //Fix up
        //Delete user/profile
        //[HttpPost("DeleteUser")]
        //public bool DeleteUser()

        //Get session info after logged in's info
        [HttpPost("getUserSessionInfo")]
        public object getUserSessionInfo(LoginVM logindetails)
        {
            try
            {
                var user = _rep.getUserSessionInfo(logindetails);
                return user;
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }
    }
}
