﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SAiCSInnovationsAPI_3._0.Models
{
    public partial class Package
    {
        public Package()
        {
            CartItems = new HashSet<CartItem>();
            OrderItems = new HashSet<OrderItem>();
            PackagePrices = new HashSet<PackagePrice>();
        }

        public int PackageId { get; set; }
        public int? PackageTypeId { get; set; }
        public string PackageName { get; set; }
        public string Description { get; set; }
        public string PackageImage { get; set; }
        public string Status { get; set; }

        public virtual PackageType PackageType { get; set; }
        public virtual ICollection<CartItem> CartItems { get; set; }
        public virtual ICollection<OrderItem> OrderItems { get; set; }
        public virtual ICollection<PackagePrice> PackagePrices { get; set; }
    }
}
