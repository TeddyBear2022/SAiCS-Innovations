﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SAiCSInnovationsAPI_3._0.Models
{
    public partial class OrderAddress
    {
        public OrderAddress()
        {
            Orders = new HashSet<Order>();
        }

        public int OrderAddressId { get; set; }
        public string Address { get; set; }
        public int? PostalCode { get; set; }
        public string City { get; set; }

        public virtual ICollection<Order> Orders { get; set; }
    }
}
