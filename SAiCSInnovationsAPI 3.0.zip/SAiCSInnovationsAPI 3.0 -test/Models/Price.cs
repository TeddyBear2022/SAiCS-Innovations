﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SAiCSInnovationsAPI_3._0.Models
{
    public partial class Price
    {
        public Price()
        {
            PackagePrices = new HashSet<PackagePrice>();
            ProductPrices = new HashSet<ProductPrice>();
            SpecialPrices = new HashSet<SpecialPrice>();
        }

        public int PriceId { get; set; }
        public decimal? Price1 { get; set; }

        public virtual ICollection<PackagePrice> PackagePrices { get; set; }
        public virtual ICollection<ProductPrice> ProductPrices { get; set; }
        public virtual ICollection<SpecialPrice> SpecialPrices { get; set; }
    }
}
