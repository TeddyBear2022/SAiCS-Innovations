﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SAiCSInnovationsAPI_3._0.Models
{
    public partial class Faqcategory
    {
        public int FaqcategoryId { get; set; }
        public int? FaqtypeId { get; set; }
        public string CategoryName { get; set; }

        public virtual Faqtype Faqtype { get; set; }
    }
}
