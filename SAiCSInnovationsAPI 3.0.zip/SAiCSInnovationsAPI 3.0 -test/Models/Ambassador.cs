﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SAiCSInnovationsAPI_3._0.Models
{
    public partial class Ambassador
    {
        public Ambassador()
        {
            AmbassadorEnrollments = new HashSet<AmbassadorEnrollment>();
            AuditTrails = new HashSet<AuditTrail>();
            Clients = new HashSet<Client>();
            Feedbacks = new HashSet<Feedback>();
            PositionRequests = new HashSet<PositionRequest>();
            ReferralCodes = new HashSet<ReferralCode>();
        }

        public int AmbassadorId { get; set; }
        public int? BankAccountId { get; set; }
        public string UserId { get; set; }
        public int? AmbassadorTypeId { get; set; }
        public string Idnumber { get; set; }
        public string Idphoto { get; set; }
        public byte[] ProofOfAddress { get; set; }
        public string AliasName { get; set; }

        public virtual AmbassadorType AmbassadorType { get; set; }
        public virtual BankAccount BankAccount { get; set; }
        public virtual User User { get; set; }
        public virtual ICollection<AmbassadorEnrollment> AmbassadorEnrollments { get; set; }
        public virtual ICollection<AuditTrail> AuditTrails { get; set; }
        public virtual ICollection<Client> Clients { get; set; }
        public virtual ICollection<Feedback> Feedbacks { get; set; }
        public virtual ICollection<PositionRequest> PositionRequests { get; set; }
        public virtual ICollection<ReferralCode> ReferralCodes { get; set; }
    }
}
