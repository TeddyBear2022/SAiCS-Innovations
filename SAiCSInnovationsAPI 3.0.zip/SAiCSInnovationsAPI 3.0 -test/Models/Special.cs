﻿using System;
using System.Collections.Generic;

#nullable disable

namespace SAiCSInnovationsAPI_3._0.Models
{
    public partial class Special
    {
        public Special()
        {
            CartItems = new HashSet<CartItem>();
            OrderItems = new HashSet<OrderItem>();
            SpecialPrices = new HashSet<SpecialPrice>();
        }

        public int SpecialId { get; set; }
        public int? SpecialTypeId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int? ProductId { get; set; }
        public string Description { get; set; }
        public string SpecialName { get; set; }

        public virtual Product Product { get; set; }
        public virtual SpecialType SpecialType { get; set; }
        public virtual ICollection<CartItem> CartItems { get; set; }
        public virtual ICollection<OrderItem> OrderItems { get; set; }
        public virtual ICollection<SpecialPrice> SpecialPrices { get; set; }
    }
}
