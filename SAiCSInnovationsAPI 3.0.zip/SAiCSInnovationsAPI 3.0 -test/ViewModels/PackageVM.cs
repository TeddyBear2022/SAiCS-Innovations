﻿using SAiCSInnovationsAPI_3._0.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAiCSInnovationsAPI_3._0.ViewModels
{
    public class PackageVM
    {
        public Package package { get; set; }
        public PackageType packageType { get; set; }
        public PackagePrice packagePrice { get; set; }
        public Price price { get; set; }
    }
}
