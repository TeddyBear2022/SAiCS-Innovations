﻿using SAiCS_Innovations_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SAiCS_Innovations_API.ViewModels
{
    public class ClientVM
    {
        public Client Client { get; set; }
        public User User { get; set; }
    }
}
