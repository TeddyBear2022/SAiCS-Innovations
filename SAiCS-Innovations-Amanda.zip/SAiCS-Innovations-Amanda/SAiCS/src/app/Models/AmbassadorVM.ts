import { Ambassador } from "./Ambassador";
import { Client } from "./Client";
import { User } from "./User";

export class AmbassadorVM
{
    Ambassador: Ambassador
    Client: Client
    User: User
}