export class Ambassador{
    ambassadorId: number
    courseId:number
    bankAccountId:number
    userId: number
    ambassadorTypeId: number
    idNumber:string
    idPhoto:number
    proofOfAddressPhoto:number
    profilePic:number
    aliasName: string
    referralCode:number
}