export class FAQ{
    faqid: number
    faqtypeId: number
    faqcategoryId: number
    faqquestion: string
    faqanswers:string

}