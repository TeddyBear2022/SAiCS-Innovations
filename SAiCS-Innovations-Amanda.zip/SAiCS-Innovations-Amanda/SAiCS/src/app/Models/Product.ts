export class Product{
    productId: number
    specialId: number
    productTypeId: number
    description: string
    quantity: number
    productName: string
    productImage: string
}