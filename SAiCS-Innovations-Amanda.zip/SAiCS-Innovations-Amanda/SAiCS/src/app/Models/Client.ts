export class Client{
    ClientId: number
    UserId: number
    AmbassadorId: number
}