export class FeedbackType{
    feedbackTypeId: number 
    feedbackTypeName: string
}