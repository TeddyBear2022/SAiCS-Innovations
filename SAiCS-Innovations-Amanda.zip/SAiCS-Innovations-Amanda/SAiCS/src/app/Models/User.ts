export class User{
    userId: number
    userRoleId: number
    titleId: number
    countryId: number
    cddressId: number
    username: string
    name: string
    surname: string
    emailAddress: string
    phoneNumber: number

}