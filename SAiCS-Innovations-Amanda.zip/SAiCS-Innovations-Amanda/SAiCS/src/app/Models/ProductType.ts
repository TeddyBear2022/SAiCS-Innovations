export class ProductType{
    productTypeId: number
    productTypeName: string
    description: string
}