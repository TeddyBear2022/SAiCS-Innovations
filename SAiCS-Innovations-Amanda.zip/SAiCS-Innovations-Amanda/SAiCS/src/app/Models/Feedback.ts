export class Feedback {
    feedbackId: number
    description: string
    productId: number
    feedbackTypeId: number
    clientId: number
    ambassadorId: number
    date: Date
}

